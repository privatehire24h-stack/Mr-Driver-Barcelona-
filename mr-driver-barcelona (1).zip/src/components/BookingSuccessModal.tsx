import React, { useState } from 'react';
import { ActiveBookingRecord, Currency } from '../types/booking';
import { 
  Check, 
  Copy, 
  MapPin, 
  Calendar, 
  Clock, 
  Car, 
  Plane, 
  MessageSquare, 
  X, 
  Navigation, 
  ShieldCheck,
  CheckCircle2,
  Phone
} from 'lucide-react';

interface BookingSuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  booking: ActiveBookingRecord | null;
  currency: Currency;
  onOpenTracker: () => void;
}

const CURRENCY_RATES: Record<Currency, { symbol: string; rate: number }> = {
  EUR: { symbol: '€', rate: 1.0 },
  USD: { symbol: '$', rate: 1.09 },
  GBP: { symbol: '£', rate: 0.85 },
};

export const BookingSuccessModal: React.FC<BookingSuccessModalProps> = ({
  isOpen,
  onClose,
  booking,
  currency,
  onOpenTracker,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !booking) return null;

  const currentRate = CURRENCY_RATES[currency] || CURRENCY_RATES.EUR;
  const convertedPrice = Math.round(booking.totalPriceEUR * currentRate.rate);
  const formattedPrice = `${currentRate.symbol}${convertedPrice}`;

  const copyRef = () => {
    if (!booking.bookingRef) return;
    navigator.clipboard.writeText(booking.bookingRef);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const openWhatsAppConfirmation = () => {
    const msg = `*MR DRIVER Barcelona - Booking Confirmed*\n\n` +
      `Booking ID: ${booking.bookingRef}\n` +
      `Passenger: ${booking.fullName}\n` +
      `Vehicle: ${booking.chauffeur?.vehicleModel || 'Executive Mercedes'}\n` +
      `Date & Time: ${booking.date} at ${booking.time}\n` +
      `Pickup: ${booking.pickupLocation}\n` +
      `Dropoff: ${booking.dropoffLocation}\n` +
      (booking.flightNumber ? `Flight: ${booking.flightNumber}\n` : '') +
      `Total: ${formattedPrice}\n\n` +
      `Please track my chauffeur dispatch. Thank you!`;
    
    window.open(`https://wa.me/34662524244?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const handleTrackRide = () => {
    onClose();
    onOpenTracker();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div 
        className="relative w-full max-w-lg bg-[#091122] border border-amber-500/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] text-slate-100"
        role="dialog"
        aria-modal="true"
        aria-labelledby="booking-success-title"
      >
        {/* Glow accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-32 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-slate-900/80 border border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto p-6 sm:p-7 space-y-5">
          
          {/* Header Icon & Status */}
          <div className="text-center pt-2 space-y-2">
            <div className="relative inline-flex items-center justify-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-emerald-400 text-slate-950 flex items-center justify-center shadow-lg shadow-emerald-500/30">
                <Check className="w-9 h-9 stroke-[3]" />
              </div>
              <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-amber-400 border-2 border-[#091122] flex items-center justify-center text-[10px] text-slate-950 font-black">
                ★
              </div>
            </div>

            <div className="space-y-1">
              <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-widest text-emerald-300 bg-emerald-950/80 border border-emerald-500/40">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Reservation Confirmed
              </span>
              <h2 id="booking-success-title" className="text-2xl sm:text-3xl font-extrabold text-white font-cinzel">
                MR DRIVER Dispatch
              </h2>
              <p className="text-xs text-slate-300 max-w-sm mx-auto">
                Your private luxury chauffeur in Barcelona has been scheduled and assigned.
              </p>
            </div>

            {/* Booking ID badge with Copy Action */}
            <div className="pt-1">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-slate-950 border border-amber-500/50 rounded-xl">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Booking ID:</span>
                <span className="font-mono text-amber-400 font-extrabold text-sm sm:text-base tracking-wider">
                  {booking.bookingRef}
                </span>
                <button
                  type="button"
                  onClick={copyRef}
                  className="p-1 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
                  title="Copy Booking ID"
                >
                  {copied ? (
                    <span className="text-[10px] text-emerald-400 font-bold">Copied!</span>
                  ) : (
                    <Copy className="w-3.5 h-3.5 text-amber-400" />
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Trip Details Summary Card */}
          <div className="rounded-2xl bg-slate-950/80 border border-slate-800/90 p-4 sm:p-5 space-y-3.5 text-xs">
            
            {/* Route */}
            <div className="space-y-2 pb-3 border-b border-slate-800/80">
              <div className="flex items-start gap-2.5">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 shrink-0 mt-1" />
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Pick-Up Location</div>
                  <div className="text-sm font-semibold text-white truncate">{booking.pickupLocation}</div>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="w-2.5 h-2.5 rounded-full bg-amber-400 shrink-0 mt-1" />
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Destination</div>
                  <div className="text-sm font-semibold text-white truncate">{booking.dropoffLocation}</div>
                </div>
              </div>
            </div>

            {/* Quick Metrics Grid */}
            <div className="grid grid-cols-2 gap-3 text-slate-300">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-slate-500 block">Date &amp; Time</span>
                <span className="font-medium text-white flex items-center gap-1.5 mt-0.5">
                  <Calendar className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>{booking.date} at {booking.time}</span>
                </span>
              </div>

              <div>
                <span className="text-[10px] uppercase tracking-wider text-slate-500 block">Lead Passenger</span>
                <span className="font-medium text-white block mt-0.5 truncate">{booking.fullName}</span>
              </div>

              <div>
                <span className="text-[10px] uppercase tracking-wider text-slate-500 block">Vehicle &amp; Chauffeur</span>
                <span className="font-medium text-white flex items-center gap-1.5 mt-0.5 truncate">
                  <Car className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>{booking.chauffeur?.vehicleModel || 'Mercedes-Maybach'}</span>
                </span>
                <span className="text-[10px] text-amber-400 font-mono block">
                  Chauffeur: {booking.chauffeur?.name || 'Alejandro Morales'} ({booking.chauffeur?.vehiclePlate || '9421-LMB'})
                </span>
              </div>

              <div>
                <span className="text-[10px] uppercase tracking-wider text-slate-500 block">Guaranteed Fare</span>
                <span className="font-mono font-bold text-amber-400 text-base block mt-0.5">
                  {formattedPrice}
                </span>
                <span className="text-[10px] text-slate-400">Fixed, all-inclusive</span>
              </div>
            </div>

            {booking.flightNumber && (
              <div className="p-2.5 bg-slate-900/90 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <Plane className="w-3.5 h-3.5 text-amber-400" />
                  <span>Flight Monitoring:</span>
                </span>
                <span className="font-mono text-amber-400 font-bold">{booking.flightNumber}</span>
              </div>
            )}
          </div>

          {/* Action CTAs: Track Ride & WhatsApp Dispatch */}
          <div className="space-y-2.5 pt-1">
            <button
              type="button"
              onClick={handleTrackRide}
              className="w-full py-3.5 px-4 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 text-slate-950 hover:brightness-110 shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Navigation className="w-4 h-4 fill-slate-950 stroke-none" />
              <span>View My Ride Status (Live Radar)</span>
            </button>

            <button
              type="button"
              onClick={openWhatsAppConfirmation}
              className="w-full py-3 px-4 rounded-xl font-semibold text-xs bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-500/40 flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Send Confirmation to WhatsApp (+34 662 524 244)</span>
            </button>
          </div>

          {/* Footer note */}
          <div className="text-center pt-1">
            <button
              type="button"
              onClick={onClose}
              className="text-xs text-slate-400 hover:text-white transition-colors cursor-pointer underline underline-offset-4"
            >
              Close &amp; View Digital Voucher Pass
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
