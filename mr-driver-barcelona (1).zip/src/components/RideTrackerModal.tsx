import React, { useState } from 'react';
import { X, Search, ShieldCheck, MapPin, Phone, MessageSquare, Plane, Clock, CheckCircle2 } from 'lucide-react';
import { ActiveBookingRecord } from '../types/booking';

interface RideTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeBooking?: ActiveBookingRecord | null;
}

export const RideTrackerModal: React.FC<RideTrackerModalProps> = ({
  isOpen,
  onClose,
  activeBooking,
}) => {
  const [searchRef, setSearchRef] = useState(activeBooking?.bookingRef || 'MRD-84920');
  const [activeTab, setActiveTab] = useState<'overview' | 'driver' | 'flight'>('overview');

  if (!isOpen) return null;

  // Mock demo record if none passed
  const booking: ActiveBookingRecord = activeBooking || {
    id: searchRef || 'MRD-84920',
    bookingRef: searchRef || 'MRD-84920',
    serviceType: 'airport',
    pickupLocation: 'BCN Josep Tarradellas Airport - Terminal 1 (Arrivals)',
    dropoffLocation: 'Hotel Arts Barcelona (The Ritz-Carlton)',
    date: 'Today',
    time: '15:45',
    passengers: 2,
    luggage: 2,
    flightNumber: 'IB2601 (Iberia from London LHR)',
    meetAndGreetName: 'Mr. David Sterling',
    childSeat: false,
    boosterSeat: false,
    selectedVehicleId: 'first-class-maybach',
    fullName: 'David Sterling',
    email: 'd.sterling@example.com',
    phone: '+34 612 000 111',
    totalPriceEUR: 130,
    currency: 'EUR',
    createdAt: new Date().toISOString(),
    status: 'assigned',
    chauffeur: {
      name: 'Alejandro Morales',
      phone: '+34 662 524 244',
      rating: 4.99,
      tripsCount: 1420,
      vehiclePlate: '9421-LMB',
      vehicleModel: 'Mercedes-Maybach S 580 (Obsidian Black)',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
      status: 'waiting_arrival',
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-[#091122] border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden text-slate-200">
        
        {/* Top Header */}
        <div className="p-5 bg-gradient-to-r from-[#0d1a33] to-[#0a1222] border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Search className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base font-cinzel">Chauffeur Dispatch Radar</h3>
              <p className="text-xs text-slate-400">MR DRIVER Barcelona Real-time Journey Monitor</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-4 bg-slate-950/60 border-b border-slate-800 flex gap-2">
          <input
            type="text"
            value={searchRef}
            onChange={(e) => setSearchRef(e.target.value.toUpperCase())}
            placeholder="Enter Booking Reference (e.g. MRD-84920)"
            className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs sm:text-sm text-white font-mono uppercase focus:outline-none focus:border-amber-400"
          />
          <button
            type="button"
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg cursor-pointer"
          >
            Track Ride
          </button>
        </div>

        {/* Chauffeur Live Status Card */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1">
          
          {/* Status Badge & Radar simulation */}
          <div className="p-4 bg-gradient-to-r from-emerald-950/40 to-slate-900 rounded-xl border border-emerald-500/30 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse"></div>
              <div>
                <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                  Chauffeur Position: At BCN Terminal 1 VIP Parking
                </div>
                <div className="text-xs text-slate-300">
                  Awaiting passenger flight touchdown · Free 60-min buffer active
                </div>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-400 uppercase block">Ref Code</span>
              <span className="font-mono text-sm font-bold text-amber-400">{booking.bookingRef}</span>
            </div>
          </div>

          {/* Assigned Driver Profile */}
          <div className="p-4 bg-slate-900/80 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-14 h-14 rounded-full bg-slate-800 border-2 border-amber-500/40 overflow-hidden flex items-center justify-center text-amber-400 font-bold text-lg">
                AM
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-white text-sm">{booking.chauffeur.name}</h4>
                  <span className="text-xs text-amber-400 font-bold">★ {booking.chauffeur.rating}</span>
                </div>
                <div className="text-xs text-slate-400">
                  {booking.chauffeur.tripsCount} VIP Transfers completed
                </div>
                <div className="text-xs text-slate-300 mt-1 font-mono">
                  {booking.chauffeur.vehicleModel} · Plate: <span className="text-amber-400 font-bold">{booking.chauffeur.vehiclePlate}</span>
                </div>
              </div>
            </div>

            {/* Quick Contact buttons */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <a
                href="https://wa.me/34662524244"
                target="_blank"
                rel="noreferrer"
                className="flex-1 sm:flex-initial px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </a>

              <a
                href="tel:+34662524244"
                className="flex-1 sm:flex-initial px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>Call Chauffeur</span>
              </a>
            </div>
          </div>

          {/* Trip Details Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div>
              <span className="text-slate-500 block uppercase tracking-wider text-[10px]">Pickup Location</span>
              <span className="text-white font-medium">{booking.pickupLocation}</span>
            </div>

            <div>
              <span className="text-slate-500 block uppercase tracking-wider text-[10px]">Drop-off Destination</span>
              <span className="text-white font-medium">{booking.dropoffLocation}</span>
            </div>

            {booking.flightNumber && (
              <div>
                <span className="text-slate-500 block uppercase tracking-wider text-[10px]">Flight Monitored</span>
                <span className="text-amber-400 font-semibold">{booking.flightNumber}</span>
              </div>
            )}

            {booking.meetAndGreetName && (
              <div>
                <span className="text-slate-500 block uppercase tracking-wider text-[10px]">Nameboard Display</span>
                <span className="text-white font-medium">"{booking.meetAndGreetName}"</span>
              </div>
            )}
          </div>

          <div className="text-center pt-2">
            <p className="text-[11px] text-slate-400">
              Need assistance or schedule changes? Contact MR DRIVER 24/7 Concierge Hotline: <a href="tel:+34662524244" className="text-amber-400 font-bold hover:underline">+34 662 524 244</a>
            </p>
          </div>

        </div>

      </div>
    </div>
  );
};
