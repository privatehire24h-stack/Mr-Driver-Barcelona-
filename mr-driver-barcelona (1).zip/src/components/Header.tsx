import React, { useState } from 'react';
import { BrandLogo } from './BrandLogo';
import { Menu, X, PhoneCall, Search, MessageSquare, Mail, MapPin, Download } from 'lucide-react';
import { Currency } from '../types/booking';
import { PWAInstallButton } from './pwa/PWAInstallButton';

interface HeaderProps {
  onOpenBooking: () => void;
  onOpenTracker: () => void;
  currency: Currency;
  setCurrency: (c: Currency) => void;
  activeTab?: 'book' | 'fleet' | 'trips' | 'about' | 'contact';
  onSelectTab?: (tab: 'book' | 'fleet' | 'trips' | 'about' | 'contact') => void;
  panelMode?: 'rider' | 'driver';
  onSelectPanelMode?: (mode: 'rider' | 'driver') => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenBooking,
  onOpenTracker,
  currency,
  setCurrency,
  activeTab = 'book',
  onSelectTab,
  panelMode = 'rider',
  onSelectPanelMode,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-[#070d18]/95 backdrop-blur-md border-b border-slate-800/80 transition-all">
      {/* 24/7 VIP Concierge & Contact Bar */}
      <div className="bg-[#050912] border-b border-slate-800/60 py-1.5 px-4 text-[11px] text-slate-400">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="hidden sm:flex items-center gap-1.5">
            <MapPin className="w-3 h-3 text-amber-400 shrink-0" />
            <span>Terminal 1 El Prat de Llobregat, Barcelona</span>
          </div>
          <div className="flex items-center justify-between sm:justify-end w-full sm:w-auto gap-4 sm:gap-6 text-[11px]">
            <a
              href="https://wa.me/34662524244"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-mono transition-colors"
            >
              <MessageSquare className="w-3 h-3" />
              <span>WhatsApp: +34 662 52 42 44</span>
            </a>
            <a
              href="mailto:privatehire24h@gmail.com"
              className="hidden md:flex items-center gap-1.5 hover:text-white transition-colors"
            >
              <Mail className="w-3 h-3 text-amber-400" />
              <span>privatehire24h@gmail.com</span>
            </a>
            <a
              href="tel:+34662524244"
              className="flex items-center gap-1.5 hover:text-amber-400 font-mono transition-colors"
            >
              <PhoneCall className="w-3 h-3 text-amber-400" />
              <span>+34 662 52 42 44</span>
            </a>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Strict 3-Zone Top Bar Contract */}
        <div className="flex items-center justify-between gap-8 h-20">
          
          {/* Zone 1: Brand Wordmark */}
          <a href="#home" className="flex items-center whitespace-nowrap shrink-0 focus:outline-none">
            <BrandLogo />
          </a>

          {/* Zone 2: Clean Nav Links / Tab Switcher */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-300">
            <button
              type="button"
              onClick={() => onSelectTab ? onSelectTab('book') : onOpenBooking()}
              className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'book' ? 'text-amber-400 font-bold' : 'hover:text-amber-400'
              }`}
            >
              Book Transfer
            </button>
            <button
              type="button"
              onClick={() => onSelectTab ? onSelectTab('fleet') : undefined}
              className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'fleet' ? 'text-amber-400 font-bold' : 'hover:text-amber-400'
              }`}
            >
              Fleet &amp; Rates
            </button>
            <button
              type="button"
              onClick={() => onSelectTab ? onSelectTab('trips') : undefined}
              className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'trips' ? 'text-amber-400 font-bold' : 'hover:text-amber-400'
              }`}
            >
              Day Trips
            </button>
            <button
              type="button"
              onClick={() => onSelectTab ? onSelectTab('about') : undefined}
              className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'about' ? 'text-amber-400 font-bold' : 'hover:text-amber-400'
              }`}
            >
              About &amp; VTC
            </button>
            <button
              type="button"
              onClick={() => onSelectTab ? onSelectTab('contact') : undefined}
              className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'contact' ? 'text-amber-400 font-bold' : 'hover:text-amber-400'
              }`}
            >
              Contact
            </button>
            <button
              type="button"
              onClick={onOpenTracker}
              className="text-slate-300 hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer text-xs"
            >
              <Search className="w-3.5 h-3.5 text-amber-400" />
              Ride Status
            </button>
          </nav>

          {/* Zone 3: 1 Primary Action + PWA Install + User Auth Dropdown + Currency */}
          <div className="flex items-center gap-2.5 sm:gap-4 shrink-0">
            {/* PWA Mobile App Install Button */}
            <PWAInstallButton variant="header" />

            {/* Rider / Driver Portal Mode Switcher */}
            <div className="flex items-center p-0.5 bg-slate-900 border border-slate-700/80 rounded-lg text-xs font-semibold">
              <button
                type="button"
                onClick={() => onSelectPanelMode?.('rider')}
                className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                  panelMode === 'rider' ? 'bg-amber-400 text-slate-950 font-bold shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                👤 Rider
              </button>
              <button
                type="button"
                onClick={() => onSelectPanelMode?.('driver')}
                className={`px-2.5 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1 ${
                  panelMode === 'driver' ? 'bg-amber-400 text-slate-950 font-bold shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Driver</span>
              </button>
            </div>

            {/* Currency selector */}
            <div className="hidden lg:flex items-center bg-slate-900/90 border border-slate-800 rounded-lg p-0.5 text-xs text-slate-400">
              {(['EUR', 'USD', 'GBP'] as Currency[]).map((cur) => (
                <button
                  key={cur}
                  onClick={() => setCurrency(cur)}
                  className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                    currency === cur
                      ? 'bg-amber-500 text-slate-950 font-semibold shadow-xs'
                      : 'hover:text-white'
                  }`}
                >
                  {cur === 'EUR' ? '€ EUR' : cur === 'USD' ? '$ USD' : '£ GBP'}
                </button>
              ))}
            </div>

            {/* Primary Action Button */}
            <button
              onClick={onOpenBooking}
              className="px-4 sm:px-5 py-2 sm:py-2.5 text-xs sm:text-sm font-semibold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 rounded-lg shadow-md shadow-amber-500/20 transition-all hover:scale-[1.02] active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer"
            >
              Book Chauffeur
            </button>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-400 hover:text-white rounded-lg focus:outline-none cursor-pointer"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-800 bg-[#091122] px-4 pt-3 pb-6 space-y-3 shadow-xl">
          {/* Mobile Portal Mode Switcher */}
          <div className="p-1 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between text-xs font-semibold mb-2">
            <button
              type="button"
              onClick={() => {
                onSelectPanelMode?.('rider');
                setMobileMenuOpen(false);
              }}
              className={`flex-1 py-2 rounded-lg text-center transition-all cursor-pointer ${
                panelMode === 'rider' ? 'bg-amber-400 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              👤 Rider Portal
            </button>
            <button
              type="button"
              onClick={() => {
                onSelectPanelMode?.('driver');
                setMobileMenuOpen(false);
              }}
              className={`flex-1 py-2 rounded-lg text-center transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                panelMode === 'driver' ? 'bg-amber-400 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>🚘 Driver Dispatch</span>
            </button>
          </div>

          <nav className="flex flex-col space-y-1.5 text-sm font-medium text-slate-200">
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                if (onSelectTab) onSelectTab('book');
                else onOpenBooking();
              }}
              className={`text-left px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'book' ? 'bg-amber-500/20 text-amber-400 font-bold' : 'hover:bg-slate-800/80 hover:text-amber-400'
              }`}
            >
              Book Transfer (Step-by-Step)
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                if (onSelectTab) onSelectTab('fleet');
              }}
              className={`text-left px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'fleet' ? 'bg-amber-500/20 text-amber-400 font-bold' : 'hover:bg-slate-800/80 hover:text-amber-400'
              }`}
            >
              Mercedes &amp; Tesla Fleet &amp; Rates
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                if (onSelectTab) onSelectTab('trips');
              }}
              className={`text-left px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'trips' ? 'bg-amber-500/20 text-amber-400 font-bold' : 'hover:bg-slate-800/80 hover:text-amber-400'
              }`}
            >
              Catalonia Day Trips (Montserrat, Andorra)
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                if (onSelectTab) onSelectTab('about');
              }}
              className={`text-left px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'about' ? 'bg-amber-500/20 text-amber-400 font-bold' : 'hover:bg-slate-800/80 hover:text-amber-400'
              }`}
            >
              About MR DRIVER &amp; VTC Licensure
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                if (onSelectTab) onSelectTab('contact');
              }}
              className={`text-left px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'contact' ? 'bg-amber-500/20 text-amber-400 font-bold' : 'hover:bg-slate-800/80 hover:text-amber-400'
              }`}
            >
              Contact &amp; 24/7 Concierge
            </button>
            
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBooking();
              }}
              className="w-full py-2.5 px-3 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-center text-sm shadow-md mt-1 cursor-pointer"
            >
              Instant Online Booking
            </button>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenTracker();
              }}
              className="flex items-center gap-2 px-3 py-2 text-left rounded-lg hover:bg-slate-800/80 hover:text-amber-400 transition-colors text-amber-400 font-medium cursor-pointer"
            >
              <Search className="w-4 h-4" />
              Check Ride / Flight Status
            </button>

            <a
              href="/mr-driver-barcelona.zip"
              download="mr-driver-barcelona.zip"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 px-3 py-2 text-left rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 font-semibold hover:bg-amber-500/20 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download Project ZIP (Vercel Ready)</span>
            </a>
            {/* Direct Mobile Contact Card */}
            <div className="pt-3 border-t border-slate-800 space-y-2 text-xs">
              <div className="text-[10px] text-amber-400 font-bold uppercase tracking-wider">
                24/7 VIP Concierge &amp; Dispatch
              </div>
              <a
                href="https://wa.me/34662524244"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/40 text-emerald-400 font-semibold"
              >
                <MessageSquare className="w-4 h-4" />
                <span>WhatsApp: +34 662 52 42 44</span>
              </a>
              <div className="grid grid-cols-2 gap-2">
                <a
                  href="tel:+34662524244"
                  className="flex items-center justify-center gap-1.5 p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 hover:text-white"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                  <span>Call 24/7</span>
                </a>
                <a
                  href="mailto:privatehire24h@gmail.com"
                  className="flex items-center justify-center gap-1.5 p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 hover:text-white"
                >
                  <Mail className="w-3.5 h-3.5 text-amber-400" />
                  <span>Email</span>
                </a>
              </div>
              <div className="flex items-start gap-1.5 text-[11px] text-slate-400 pt-1">
                <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span>Terminal 1 elprat de Llobregat Barcelona</span>
              </div>
            </div>
          </nav>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-400">Currency</span>
            <div className="flex gap-1 text-xs">
              {(['EUR', 'USD', 'GBP'] as Currency[]).map((cur) => (
                <button
                  key={cur}
                  onClick={() => setCurrency(cur)}
                  className={`px-2.5 py-1 rounded text-xs cursor-pointer ${
                    currency === cur ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 bg-slate-800'
                  }`}
                >
                  {cur}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
