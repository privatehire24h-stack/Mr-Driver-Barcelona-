import React, { useState } from 'react';
import { MessageSquare, X } from 'lucide-react';

export const WhatsAppFloating: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  const openWhatsApp = () => {
    const text = encodeURIComponent(
      'Hello MR DRIVER Barcelona, I would like to inquire about a luxury chauffeur transfer / day trip.'
    );
    window.open(`https://wa.me/34662524244?text=${text}`, '_blank');
  };

  return (
    <div className="fixed bottom-5 right-4 sm:bottom-6 sm:right-6 z-40 flex items-end gap-3">
      {/* Tooltip Bubble */}
      {showTooltip && (
        <div className="hidden sm:flex items-center gap-2 bg-[#091122] text-slate-200 border border-emerald-500/40 px-3.5 py-2 rounded-xl shadow-2xl text-xs backdrop-blur-md animate-fade-in">
          <span>Need VIP chauffeur assistance? WhatsApp: <strong className="text-emerald-400">+34 662 52 42 44</strong></span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowTooltip(false);
            }}
            className="text-slate-400 hover:text-white ml-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating Action Button */}
      <button
        type="button"
        onClick={openWhatsApp}
        className="w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-lg shadow-emerald-500/30 hover:scale-105 active:scale-95 transition-all cursor-pointer relative group"
        aria-label="Chat with MR DRIVER on WhatsApp"
      >
        <MessageSquare className="w-6 h-6 fill-white stroke-none" />
        <span className="sr-only">WhatsApp Concierge</span>
      </button>
    </div>
  );
};
