import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { ActiveBookingRecord, Currency } from '../types/booking';
import { 
  Car, 
  MapPin, 
  Clock, 
  Plane, 
  Users, 
  Briefcase, 
  Phone, 
  MessageSquare, 
  Navigation, 
  CheckCircle2, 
  Tablet, 
  X, 
  ShieldCheck, 
  ChevronRight, 
  DollarSign, 
  Sparkles,
  AlertCircle
} from 'lucide-react';
import userLogoImg from '../assets/images/mr_driver_user_logo.jpg';

interface DriverPanelProps {
  currency: Currency;
  onSwitchToRider: () => void;
}

export const DriverPanel: React.FC<DriverPanelProps> = ({ currency, onSwitchToRider }) => {
  const { bookings, updateBookingStatus } = useAuth();
  const [dutyStatus, setDutyStatus] = useState<'online' | 'busy' | 'offline'>('online');
  const [activeTab, setActiveTab] = useState<'active' | 'completed' | 'radar'>('active');
  const [signboardBooking, setSignboardBooking] = useState<ActiveBookingRecord | null>(null);

  const activeTrips = bookings.filter(b => b.status !== 'completed' && b.status !== 'cancelled');
  const completedTrips = bookings.filter(b => b.status === 'completed');

  // Today's total driver revenue
  const totalRevenueEUR = completedTrips.reduce((acc, curr) => acc + (curr.totalPriceEUR || 85), 0) + 240;

  const handleUpdateStatus = (
    bookingId: string, 
    status: 'confirmed' | 'assigned' | 'en_route' | 'completed',
    chauffeurStatus?: 'assigned' | 'approaching' | 'waiting_arrival' | 'in_transit'
  ) => {
    updateBookingStatus(bookingId, status, chauffeurStatus);
  };

  const handleOpenGoogleMaps = (destination: string) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}`;
    window.open(url, '_blank');
  };

  const handleContactRiderWhatsApp = (booking: ActiveBookingRecord) => {
    const phoneClean = booking.phone.replace(/[^0-9]/g, '') || '34662524244';
    const text = `Hello ${booking.fullName || 'Guest'}, this is your MR DRIVER chauffeur Alejandro Morales (Mercedes-Benz Plate: 9421-LMB). I am ready for your transfer from ${booking.pickupLocation} to ${booking.dropoffLocation}. Please let me know once you exit baggage claim.`;
    window.open(`https://wa.me/${phoneClean}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      
      {/* Driver Header Profile & Duty Status */}
      <div className="rounded-2xl bg-gradient-to-r from-[#0a1222] via-[#0d1a33] to-[#0a1222] border border-amber-500/30 p-5 sm:p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-5 relative z-10">
          
          <div className="flex items-center gap-4 text-center sm:text-left">
            {/* Chauffeur Avatar */}
            <div className="relative">
              <div className="w-16 h-16 sm:w-18 sm:h-18 rounded-2xl p-1 bg-gradient-to-tr from-amber-500 to-amber-300 shadow-xl overflow-hidden shrink-0">
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300"
                  alt="Alejandro Morales - Senior Chauffeur"
                  className="w-full h-full object-cover rounded-xl"
                />
              </div>
              <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-slate-950 ${
                dutyStatus === 'online' ? 'bg-emerald-400' : dutyStatus === 'busy' ? 'bg-amber-400' : 'bg-slate-500'
              }`} />
            </div>

            <div>
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <h2 className="text-xl font-bold text-white font-cinzel">Alejandro Morales</h2>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-950/70 border border-amber-500/40 px-2 py-0.5 rounded-full">
                  Lead Chauffeur
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Assigned: <strong className="text-white">Mercedes-Maybach / V-Class</strong> • Plate: <strong className="text-amber-400 font-mono">9421-LMB</strong>
              </p>
              <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 justify-center sm:justify-start">
                <span>VTC Lic: <strong>CAT-84920</strong></span>
                <span>•</span>
                <span>Rating: <strong className="text-amber-400">4.99 ★</strong> (1,420 trips)</span>
              </div>
            </div>
          </div>

          {/* Duty Switcher & Quick Rider Switch */}
          <div className="flex flex-col sm:items-end gap-3 w-full sm:w-auto">
            <div className="flex items-center justify-center gap-1.5 p-1 bg-slate-900/90 rounded-xl border border-slate-800 text-xs">
              <button
                type="button"
                onClick={() => setDutyStatus('online')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                  dutyStatus === 'online' ? 'bg-emerald-500 text-slate-950 font-bold shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                ● Available
              </button>
              <button
                type="button"
                onClick={() => setDutyStatus('busy')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                  dutyStatus === 'busy' ? 'bg-amber-400 text-slate-950 font-bold shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                ● On Trip
              </button>
              <button
                type="button"
                onClick={() => setDutyStatus('offline')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                  dutyStatus === 'offline' ? 'bg-slate-700 text-white font-bold shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                ● Break
              </button>
            </div>

            <button
              type="button"
              onClick={onSwitchToRider}
              className="text-xs text-amber-400 hover:text-amber-300 font-semibold underline text-center sm:text-right cursor-pointer"
            >
              ← Return to Passenger / Rider Booking Panel
            </button>
          </div>

        </div>

        {/* Live Chauffeur Metrics Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-slate-800 text-center">
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase tracking-wider">Today's Revenue</div>
            <div className="text-lg font-bold text-emerald-400 font-mono">€{totalRevenueEUR}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase tracking-wider">Trips Dispatched</div>
            <div className="text-lg font-bold text-white font-mono">{activeTrips.length + completedTrips.length}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase tracking-wider">Active Queue</div>
            <div className="text-lg font-bold text-amber-400 font-mono">{activeTrips.length}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase tracking-wider">Base Terminal</div>
            <div className="text-xs font-bold text-slate-200 mt-1">Terminal 1 El Prat</div>
          </div>
        </div>
      </div>

      {/* Tabs: Active Trips / Completed History / Flight Telemetry */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          type="button"
          onClick={() => setActiveTab('active')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
            activeTab === 'active'
              ? 'bg-amber-400 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
          }`}
        >
          Active Reservations ({activeTrips.length})
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('completed')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
            activeTab === 'completed'
              ? 'bg-amber-400 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
          }`}
        >
          Completed Transfers ({completedTrips.length})
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('radar')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
            activeTab === 'radar'
              ? 'bg-amber-400 text-slate-950 font-bold shadow-md'
              : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
          }`}
        >
          Airport Radar (T1 &amp; T2)
        </button>
      </div>

      {/* ACTIVE DISPATCH QUEUE */}
      {activeTab === 'active' && (
        <div className="space-y-4">
          {activeTrips.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-slate-900/40 border border-slate-800 text-slate-400 space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
              <p className="font-semibold text-white">All Dispatches Completed!</p>
              <p className="text-xs">No pending rides in queue. Standing by at Terminal 1 VIP Lane.</p>
            </div>
          ) : (
            activeTrips.map((booking) => {
              const currentStatus = booking.status || 'confirmed';

              return (
                <div
                  key={booking.id}
                  className="rounded-2xl bg-[#091122] border border-slate-800 hover:border-amber-500/40 p-5 sm:p-6 shadow-xl transition-all space-y-4"
                >
                  {/* Top Bar: Ref + Status Badge + Fare */}
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-mono font-bold text-amber-400 bg-amber-950/70 px-2.5 py-1 rounded-md border border-amber-500/30">
                        #{booking.bookingRef || booking.id}
                      </span>
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                        {booking.serviceType === 'airport' ? '✈️ Airport Transfer' : booking.serviceType === 'hourly' ? '⏱️ Hourly Chauffeur' : booking.serviceType === 'day_trip' ? '⛰️ Day Trip' : '🏙️ City Transfer'}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className={`text-xs px-2.5 py-1 rounded-full font-bold uppercase tracking-wider border ${
                        currentStatus === 'en_route'
                          ? 'bg-blue-950/80 text-blue-400 border-blue-500/40 animate-pulse'
                          : currentStatus === 'assigned'
                          ? 'bg-amber-950/80 text-amber-400 border-amber-500/40'
                          : 'bg-emerald-950/80 text-emerald-400 border-emerald-500/40'
                      }`}>
                        {currentStatus === 'en_route' ? 'En Route to Pick-Up' : currentStatus === 'assigned' ? 'Waiting at Arrivals' : 'Confirmed Dispatch'}
                      </span>
                      <span className="text-base font-bold text-white font-mono">
                        €{booking.totalPriceEUR || 85}
                      </span>
                    </div>
                  </div>

                  {/* Rider & Route Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                    {/* Route */}
                    <div className="space-y-2 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
                      <div className="flex items-start gap-2">
                        <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <div>
                          <div className="text-[10px] uppercase text-slate-500 font-bold">Pick-Up Location</div>
                          <div className="text-white font-semibold">{booking.pickupLocation}</div>
                        </div>
                      </div>

                      <div className="flex items-start gap-2 pt-1 border-t border-slate-800/60">
                        <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <div>
                          <div className="text-[10px] uppercase text-slate-500 font-bold">Destination</div>
                          <div className="text-white font-semibold">{booking.dropoffLocation}</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-slate-400 pt-1 text-[11px]">
                        <span>📅 {booking.date}</span>
                        <span>⏰ {booking.time}</span>
                        <span>👥 {booking.passengers} Pax</span>
                        <span>🧳 {booking.luggage} Bags</span>
                      </div>
                    </div>

                    {/* Rider Details & Airport Meet */}
                    <div className="space-y-2 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
                      <div>
                        <div className="text-[10px] uppercase text-slate-500 font-bold">Passenger Details</div>
                        <div className="text-white font-bold text-sm">{booking.fullName || 'VIP Guest'}</div>
                        <div className="text-slate-400 text-xs font-mono">{booking.phone} • {booking.email}</div>
                      </div>

                      {booking.flightNumber && (
                        <div className="flex items-center gap-2 pt-1 text-[11px] text-amber-400 font-medium">
                          <Plane className="w-3.5 h-3.5" />
                          <span>Flight: <strong>{booking.flightNumber}</strong> (Radar active)</span>
                        </div>
                      )}

                      {booking.meetAndGreetName && (
                        <div className="text-[11px] text-slate-300">
                          Signboard Text: <strong className="text-amber-300">"{booking.meetAndGreetName}"</strong>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Chauffeur Action Controls */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                    {/* Quick Communication & Tools */}
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleContactRiderWhatsApp(booking)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>WhatsApp Rider</span>
                      </button>

                      <a
                        href={`tel:${booking.phone}`}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <Phone className="w-3.5 h-3.5 text-amber-400" />
                        <span>Call</span>
                      </a>

                      <button
                        type="button"
                        onClick={() => handleOpenGoogleMaps(booking.dropoffLocation)}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <Navigation className="w-3.5 h-3.5 text-blue-400" />
                        <span>GPS Maps</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setSignboardBooking(booking)}
                        className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <Tablet className="w-3.5 h-3.5" />
                        <span>Display Nameboard</span>
                      </button>
                    </div>

                    {/* Step-by-Step Status Updates */}
                    <div className="flex items-center gap-2">
                      {currentStatus === 'confirmed' && (
                        <button
                          type="button"
                          onClick={() => handleUpdateStatus(booking.id, 'en_route', 'approaching')}
                          className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-all shadow-md cursor-pointer"
                        >
                          🚗 Mark En Route to Pickup
                        </button>
                      )}

                      {currentStatus === 'en_route' && (
                        <button
                          type="button"
                          onClick={() => handleUpdateStatus(booking.id, 'assigned', 'waiting_arrival')}
                          className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all shadow-md cursor-pointer"
                        >
                          📍 Waiting at Arrivals Gate
                        </button>
                      )}

                      {currentStatus === 'assigned' && (
                        <button
                          type="button"
                          onClick={() => handleUpdateStatus(booking.id, 'en_route', 'in_transit')}
                          className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition-all shadow-md cursor-pointer"
                        >
                          👤 Passenger Onboard
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => handleUpdateStatus(booking.id, 'completed', 'waiting_arrival')}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all shadow-md cursor-pointer"
                      >
                        ✓ Complete Trip
                      </button>
                    </div>
                  </div>

                </div>
              );
            })
          )}
        </div>
      )}

      {/* COMPLETED TRANSFERS TAB */}
      {activeTab === 'completed' && (
        <div className="space-y-3">
          {completedTrips.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-slate-900/40 border border-slate-800 text-slate-400">
              No completed trips recorded yet today.
            </div>
          ) : (
            completedTrips.map((b) => (
              <div
                key={b.id}
                className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-bold text-white block">{b.fullName}</span>
                  <span className="text-slate-400">{b.pickupLocation} ➔ {b.dropoffLocation}</span>
                </div>
                <div className="text-right">
                  <span className="text-emerald-400 font-bold font-mono text-sm block">€{b.totalPriceEUR || 85}</span>
                  <span className="text-[10px] text-slate-500 uppercase">Settled on-board</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* AIRPORT RADAR (TERMINAL 1 & 2 TELEMETRY) */}
      {activeTab === 'radar' && (
        <div className="rounded-2xl bg-[#091122] border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-white text-base">Barcelona Airport Live Telemetry</h3>
              <p className="text-xs text-slate-400">Terminal 1 &amp; 2 Chauffeur Staging Lane Monitor</p>
            </div>
            <span className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>Telemetry Active</span>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between font-bold text-white">
                <span>Terminal 1 (VIP Arrivals Curb)</span>
                <span className="text-emerald-400">Available</span>
              </div>
              <p className="text-slate-400 text-[11px]">Free staging slots available at Corredor VIP / Planta 0 Arrivals.</p>
              <div className="text-[10px] text-amber-400">60-minute complimentary parking pass active</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between font-bold text-white">
                <span>Terminal 2 (Corporate &amp; Low-Cost)</span>
                <span className="text-emerald-400">Available</span>
              </div>
              <p className="text-slate-400 text-[11px]">Terminal 2B VIP Meeting Point open at arrivals hall column 12.</p>
              <div className="text-[10px] text-amber-400">Permit: VTC-CAT-84920</div>
            </div>
          </div>
        </div>
      )}

      {/* FULL-SCREEN LUXURY TABLET SIGNBOARD MODAL */}
      {signboardBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl">
          <div className="relative w-full max-w-3xl aspect-[4/3] bg-gradient-to-b from-[#060a12] via-[#0b1424] to-[#060a12] border-4 border-amber-400/80 rounded-3xl p-8 flex flex-col justify-between items-center text-center shadow-2xl shadow-amber-500/20">
            
            {/* Close Button */}
            <button
              type="button"
              onClick={() => setSignboardBooking(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-900 border border-slate-700 text-slate-300 hover:text-white cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Top Brand Header */}
            <div className="flex items-center gap-3 pt-4">
              <div className="w-12 h-12 rounded-xl p-0.5 bg-gradient-to-tr from-amber-500 to-amber-300">
                <img
                  src={userLogoImg}
                  alt="MR DRIVER"
                  className="w-full h-full object-cover rounded-[10px]"
                />
              </div>
              <div className="text-left">
                <div className="text-xl font-black text-white font-cinzel tracking-wider">MR DRIVER</div>
                <div className="text-[10px] uppercase font-bold tracking-[0.25em] text-amber-400">Mercedes Chauffeur Barcelona</div>
              </div>
            </div>

            {/* Passenger Name Highlight (Large iPad Welcome Display) */}
            <div className="space-y-3 my-auto">
              <div className="text-xs uppercase font-bold tracking-[0.3em] text-slate-400">
                Welcome to Barcelona
              </div>
              <h1 className="text-4xl sm:text-6xl font-black text-amber-300 font-cinzel tracking-tight drop-shadow-md">
                {signboardBooking.meetAndGreetName || signboardBooking.fullName || 'VIP GUEST'}
              </h1>
              {signboardBooking.flightNumber && (
                <div className="text-sm font-mono text-slate-300 uppercase tracking-widest pt-1">
                  Flight {signboardBooking.flightNumber}
                </div>
              )}
            </div>

            {/* Bottom Seal */}
            <div className="pb-4 text-xs text-slate-400 flex items-center gap-4 border-t border-slate-800/80 pt-3 w-full justify-between">
              <span>Chauffeur: <strong>Alejandro Morales</strong></span>
              <span className="font-mono text-amber-400 font-bold">Plate: 9421-LMB</span>
              <span>24/7 VIP Concierge</span>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
