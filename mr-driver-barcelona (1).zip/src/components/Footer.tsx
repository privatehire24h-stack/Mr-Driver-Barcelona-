import React from 'react';
import { BrandLogo } from './BrandLogo';
import { Phone, Mail, MapPin, ShieldCheck, MessageSquare } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#050912] border-t border-slate-800 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          
          {/* Brand Col */}
          <div className="md:col-span-1 space-y-4">
            <BrandLogo showTagline={true} />
            <p className="text-slate-400 text-xs leading-relaxed pt-2">
              Premier luxury chauffeur and private transfer service based in Barcelona, Spain. Specializing in airport meet &amp; greet, executive city transit, and bespoke excursions across Catalonia.
            </p>
            <div className="text-[11px] text-slate-500 font-mono">
              Licencia VTC / Transport Generalitat de Catalunya
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <div className="text-white font-semibold uppercase tracking-wider text-xs">
              Mobility Services
            </div>
            <ul className="space-y-2 text-slate-400">
              <li><a href="#services" className="hover:text-amber-400 transition-colors">BCN Airport Pick-Up (T1 &amp; T2)</a></li>
              <li><a href="#services" className="hover:text-amber-400 transition-colors">Port de Barcelona Cruise Transfers</a></li>
              <li><a href="#services" className="hover:text-amber-400 transition-colors">Point-to-Point City Transfers</a></li>
              <li><a href="#services" className="hover:text-amber-400 transition-colors">Hourly / As-Directed Chauffeur</a></li>
              <li><a href="#rates" className="hover:text-amber-400 transition-colors">Fixed Rate Price Guide</a></li>
            </ul>
          </div>

          {/* Day Trips & Tours */}
          <div className="space-y-3">
            <div className="text-white font-semibold uppercase tracking-wider text-xs">
              Catalonia Day Trips
            </div>
            <ul className="space-y-2 text-slate-400">
              <li><a href="#day-trips" className="hover:text-amber-400 transition-colors">Montserrat Royal Sanctuary Tour</a></li>
              <li><a href="#day-trips" className="hover:text-amber-400 transition-colors">Girona Medieval &amp; Costa Brava</a></li>
              <li><a href="#day-trips" className="hover:text-amber-400 transition-colors">Sitges Seaside &amp; Garraf Drive</a></li>
              <li><a href="#day-trips" className="hover:text-amber-400 transition-colors">Penedès Wine &amp; Cava Private Tastings</a></li>
              <li><a href="#booking-engine" className="hover:text-amber-400 transition-colors">Custom Pyrenees &amp; Andorra Itinerary</a></li>
            </ul>
          </div>

          {/* Contact & Socials */}
          <div className="space-y-3">
            <div className="text-white font-semibold uppercase tracking-wider text-xs">
              24/7 Concierge &amp; Dispatch
            </div>
            <div className="space-y-2.5 text-slate-300">
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span>Terminal 1 elprat de Llobregat Barcelona</span>
              </div>
              <div className="flex items-center gap-2">
                <MessageSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <a
                  href="https://wa.me/34662524244"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-emerald-400 font-mono text-emerald-400 font-medium"
                >
                  WhatsApp: +34 662 52 42 44
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <a href="tel:+34662524244" className="hover:text-white font-mono">+34 662 52 42 44</a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <a href="mailto:privatehire24h@gmail.com" className="hover:text-white">privatehire24h@gmail.com</a>
              </div>
            </div>

            {/* Dispatch & Safety Assurance */}
            <div className="pt-2">
              <div className="text-[11px] text-slate-400 uppercase tracking-wider mb-2">Executive Standards</div>
              <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800 text-[11px] text-slate-300 space-y-1">
                <div className="text-amber-400 font-bold">✓ Official VTC Licensure</div>
                <div>Passenger Public Liability Insurance</div>
                <div>60-Min Free Flight Waiting Buffer</div>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
          <div>
            © {new Date().getFullYear()} MR DRIVER Barcelona. All rights reserved. Your Journey, Our Priority.
          </div>
          <div className="flex flex-wrap items-center gap-4 sm:gap-6">
            <a
              href="/mr-driver-barcelona.zip"
              download="mr-driver-barcelona.zip"
              className="text-amber-400/90 hover:text-amber-300 font-medium transition-colors flex items-center gap-1"
            >
              <span>Download Project ZIP</span>
            </a>
            <span>·</span>
            <span className="hover:text-slate-400 cursor-pointer">Privacy Policy</span>
            <span>·</span>
            <span className="hover:text-slate-400 cursor-pointer">Terms of Carriage</span>
            <span>·</span>
            <span className="hover:text-slate-400 cursor-pointer">VIP Cancellation Policy</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
