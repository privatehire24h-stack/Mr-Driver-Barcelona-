import React, { useState } from 'react';
import { Download, Smartphone, X, Share2, PlusSquare, Check } from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'header' | 'banner' | 'card';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ variant = 'header' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [dismissedBanner, setDismissedBanner] = useState(false);

  // If already installed, hide prompt
  if (isInstalled) {
    return null;
  }

  // Header button variant
  if (variant === 'header') {
    if (isInstallable) {
      return (
        <button
          onClick={install}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 rounded-lg transition-all cursor-pointer whitespace-nowrap"
          title="Install MR DRIVER app on your device"
        >
          <Download className="w-3.5 h-3.5 text-amber-400" />
          <span>Install App</span>
        </button>
      );
    }

    if (isIOS) {
      return (
        <>
          <button
            onClick={() => setShowIOSGuide(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 rounded-lg transition-all cursor-pointer whitespace-nowrap"
            title="Install on iPhone / iPad"
          >
            <Smartphone className="w-3.5 h-3.5 text-amber-400" />
            <span>Install on iOS</span>
          </button>

          {showIOSGuide && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
              <div className="w-full max-w-sm rounded-2xl bg-[#091122] border border-amber-500/30 p-6 shadow-2xl text-slate-200">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <img
                      src="/pwa-192x192.png"
                      alt="MR DRIVER App"
                      className="w-8 h-8 rounded-full border border-amber-400"
                    />
                    <h3 className="text-base font-bold text-white font-cinzel">Install MR DRIVER</h3>
                  </div>
                  <button
                    onClick={() => setShowIOSGuide(false)}
                    className="p-1 text-slate-400 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="py-4 space-y-3 text-xs text-slate-300">
                  <p>Install our official booking app on your iPhone or iPad for instant access:</p>
                  
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center text-xs shrink-0">1</div>
                      <span>Tap the <strong className="text-white">Share</strong> icon <Share2 className="inline w-3.5 h-3.5 text-amber-400 mx-0.5" /> in Safari's bottom toolbar</span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center text-xs shrink-0">2</div>
                      <span>Scroll down and select <strong className="text-white">Add to Home Screen</strong> <PlusSquare className="inline w-3.5 h-3.5 text-amber-400 mx-0.5" /></span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center text-xs shrink-0">3</div>
                      <span>Tap <strong className="text-white">Add</strong> in the top right corner</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs cursor-pointer"
                >
                  Got It
                </button>
              </div>
            </div>
          )}
        </>
      );
    }

    return null;
  }

  // Floating Mobile Banner variant
  if (variant === 'banner') {
    if (dismissedBanner) return null;

    return (
      <div className="fixed bottom-20 left-4 right-4 md:left-6 md:right-auto md:max-w-md z-40 bg-[#091122]/95 border border-amber-500/40 rounded-2xl p-4 shadow-2xl backdrop-blur-md text-slate-200">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src="/pwa-192x192.png"
              alt="MR DRIVER App"
              className="w-12 h-12 rounded-xl border border-amber-400/60 shrink-0 object-cover"
            />
            <div>
              <h4 className="text-sm font-bold text-white font-cinzel">MR DRIVER Barcelona App</h4>
              <p className="text-[11px] text-slate-300 leading-tight mt-0.5">
                Download to your phone for 1-tap booking, offline receipts &amp; live flight radar.
              </p>
            </div>
          </div>

          <button
            onClick={() => setDismissedBanner(true)}
            className="p-1 text-slate-400 hover:text-white shrink-0 cursor-pointer"
            aria-label="Dismiss banner"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-3 flex items-center gap-2">
          {isInstallable && (
            <button
              onClick={install}
              className="flex-1 py-2 px-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install App on Phone</span>
            </button>
          )}

          {isIOS && (
            <button
              onClick={() => setShowIOSGuide(true)}
              className="flex-1 py-2 px-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Install on iPhone</span>
            </button>
          )}

          <button
            onClick={() => setDismissedBanner(true)}
            className="py-2 px-3 bg-slate-900 hover:bg-slate-800 text-slate-400 text-xs rounded-xl cursor-pointer"
          >
            Later
          </button>
        </div>

        {/* iOS Modal inside banner if triggered */}
        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
            <div className="w-full max-w-sm rounded-2xl bg-[#091122] border border-amber-500/30 p-6 shadow-2xl text-slate-200">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <img
                    src="/pwa-192x192.png"
                    alt="MR DRIVER App"
                    className="w-8 h-8 rounded-full border border-amber-400"
                  />
                  <h3 className="text-base font-bold text-white font-cinzel">Install on iPhone</h3>
                </div>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="py-4 space-y-3 text-xs text-slate-300">
                <p>Follow these quick steps in Safari to add MR DRIVER to your home screen:</p>
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 font-bold flex items-center justify-center text-xs shrink-0">1</span>
                    <span>Tap the Safari <strong>Share</strong> icon</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 font-bold flex items-center justify-center text-xs shrink-0">2</span>
                    <span>Choose <strong>Add to Home Screen</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 font-bold flex items-center justify-center text-xs shrink-0">3</span>
                    <span>Confirm by tapping <strong>Add</strong></span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return null;
};
