import React, { useState, useMemo } from 'react';
import { 
  Plane, 
  MapPin, 
  Clock, 
  Calendar, 
  Users, 
  Briefcase, 
  Check, 
  ArrowRight, 
  ShieldCheck, 
  Sparkles, 
  Phone, 
  Mail, 
  User, 
  FileText,
  Compass,
  AlertCircle,
  Copy,
  Printer,
  MessageSquare
} from 'lucide-react';
import { ServiceType, Currency, Vehicle, BookingDetails, ActiveBookingRecord } from '../types/booking';
import { FLEET_DATA } from '../data/fleet';
import { BARCELONA_LOCATIONS } from '../data/locations';
import { DAY_TRIPS } from '../data/dayTrips';
import { useAuth } from '../context/AuthContext';
import { BookingSuccessModal } from './BookingSuccessModal';

interface BookingEngineProps {
  currency: Currency;
  onBookingConfirmed: (booking: ActiveBookingRecord) => void;
  onOpenTracker: () => void;
  selectedVehiclePreset?: string | null;
  selectedDayTripPreset?: string | null;
  selectedPickupPreset?: string | null;
  selectedDropoffPreset?: string | null;
  selectedServicePreset?: ServiceType | null;
  bookingResetKey?: number;
}

const CURRENCY_RATES: Record<Currency, { symbol: string; rate: number }> = {
  EUR: { symbol: '€', rate: 1.0 },
  USD: { symbol: '$', rate: 1.09 },
  GBP: { symbol: '£', rate: 0.85 },
};

export const BookingEngine: React.FC<BookingEngineProps> = ({
  currency,
  onBookingConfirmed,
  onOpenTracker,
  selectedVehiclePreset,
  selectedDayTripPreset,
  selectedPickupPreset,
  selectedDropoffPreset,
  selectedServicePreset,
  bookingResetKey,
}) => {
  const { user, isAuthenticated, addBookingToUser } = useAuth();

  // Current active step: 1 = Ride Details, 2 = Choose Vehicle, 3 = Passenger Info, 4 = Confirmation Pass
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form states
  const [serviceType, setServiceType] = useState<ServiceType>(
    selectedDayTripPreset ? 'day_trip' : 'airport'
  );
  const [airportMode, setAirportMode] = useState<'arrival' | 'departure'>('arrival');
  const [pickup, setPickup] = useState(
    user?.defaultPickupAddress || 'BCN Josep Tarradellas Airport - Terminal 1'
  );
  const [dropoff, setDropoff] = useState('Hotel Arts Barcelona (The Ritz-Carlton)');
  
  // Set default tomorrow date
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const defaultDateStr = tomorrow.toISOString().split('T')[0];

  const [date, setDate] = useState(defaultDateStr);
  const [time, setTime] = useState('14:30');
  const [hours, setHours] = useState(4);
  const [selectedDayTripId, setSelectedDayTripId] = useState(selectedDayTripPreset || DAY_TRIPS[0].id);

  const [passengers, setPassengers] = useState(2);
  const [luggage, setLuggage] = useState(2);
  const [flightNumber, setFlightNumber] = useState('IB2601');
  const [meetAndGreetName, setMeetAndGreetName] = useState(user?.name || 'VIP Guest');
  const [childSeat, setChildSeat] = useState(false);
  const [boosterSeat, setBoosterSeat] = useState(false);

  const [selectedVehicleId, setSelectedVehicleId] = useState<string>(
    user?.preferredVehicle || selectedVehiclePreset || FLEET_DATA[0].id
  );

  // Passenger Contact details (pre-fill with user if signed in)
  const [fullName, setFullName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [specialRequests, setSpecialRequests] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Sync when user changes
  React.useEffect(() => {
    if (user) {
      if (!fullName) setFullName(user.name);
      if (!email) setEmail(user.email);
      if (!phone) setPhone(user.phone);
      if (meetAndGreetName === 'VIP Guest') setMeetAndGreetName(user.name);
    }
  }, [user]);

  // Confirmed booking state
  const [confirmedBooking, setConfirmedBooking] = useState<ActiveBookingRecord | null>(null);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [copiedRef, setCopiedRef] = useState(false);

  // When props change
  React.useEffect(() => {
    if (selectedVehiclePreset) {
      setSelectedVehicleId(selectedVehiclePreset);
    }
  }, [selectedVehiclePreset]);

  React.useEffect(() => {
    if (selectedDayTripPreset) {
      setServiceType('day_trip');
      setSelectedDayTripId(selectedDayTripPreset);
    }
  }, [selectedDayTripPreset]);

  React.useEffect(() => {
    if (selectedServicePreset) {
      setServiceType(selectedServicePreset);
    }
  }, [selectedServicePreset]);

  React.useEffect(() => {
    if (selectedPickupPreset) {
      setPickup(selectedPickupPreset);
    }
    if (selectedDropoffPreset) {
      setDropoff(selectedDropoffPreset);
    }
  }, [selectedPickupPreset, selectedDropoffPreset]);

  React.useEffect(() => {
    if (bookingResetKey && bookingResetKey > 0) {
      setStep(1);
      setConfirmedBooking(null);
      setErrorMsg('');
    }
  }, [bookingResetKey]);

  // Estimate distance or base price
  const estimatedDistanceKm = useMemo(() => {
    if (serviceType === 'day_trip') {
      const tour = DAY_TRIPS.find(t => t.id === selectedDayTripId);
      if (tour) {
        const match = tour.distance.match(/(\d+)\s*km/);
        return match ? parseInt(match[1], 10) : 120;
      }
      return 120;
    }
    if (serviceType === 'hourly') return hours * 25;
    
    // Check if pickup or dropoff matches preset
    const p1 = BARCELONA_LOCATIONS.find(l => l.name === pickup);
    const p2 = BARCELONA_LOCATIONS.find(l => l.name === dropoff);
    if (p1 && p2) {
      return Math.max(12, Math.abs(p1.distanceFromCenterKm + p2.distanceFromCenterKm));
    }
    return 18; // Average Barcelona city/airport transfer distance
  }, [serviceType, pickup, dropoff, hours, selectedDayTripId]);

  // Calculate pricing for each vehicle
  const calculateVehiclePriceEUR = (vehicle: Vehicle): number => {
    if (serviceType === 'day_trip') {
      const tour = DAY_TRIPS.find(t => t.id === selectedDayTripId) || DAY_TRIPS[0];
      const multiplier = vehicle.id === 'first-class-maybach' 
        ? 1.35 
        : vehicle.id === 'vip-van-vclass' 
        ? 1.25 
        : vehicle.id === 'tesla-model-3'
        ? 0.95
        : 1.0;
      return Math.round(tour.priceEUR * multiplier);
    }

    if (serviceType === 'hourly') {
      return Math.round(vehicle.hourlyRateEUR * hours);
    }

    // Airport & Point-to-Point
    const base = vehicle.basePriceEUR;
    const distanceCost = (estimatedDistanceKm - 10) > 0 ? (estimatedDistanceKm - 10) * vehicle.perKmRateEUR : 0;
    const extraServices = (childSeat ? 15 : 0) + (boosterSeat ? 10 : 0);
    return Math.round(base + distanceCost + extraServices);
  };

  const formatPrice = (priceEUR: number) => {
    const cur = CURRENCY_RATES[currency];
    const converted = Math.round(priceEUR * cur.rate);
    return `${cur.symbol}${converted.toLocaleString()}`;
  };

  const currentSelectedVehicle = FLEET_DATA.find(v => v.id === selectedVehicleId) || FLEET_DATA[0];
  const currentTotalEUR = calculateVehiclePriceEUR(currentSelectedVehicle);

  // Handle service type change
  const handleServiceChange = (type: ServiceType) => {
    setServiceType(type);
    if (type === 'airport') {
      setPickup('BCN Josep Tarradellas Airport - Terminal 1');
      setDropoff('Hotel Arts Barcelona (The Ritz-Carlton)');
    } else if (type === 'point_to_point') {
      setPickup('Passeig de Gràcia / Casa Batlló & La Pedrera');
      setDropoff('Port de Barcelona - Moll Adossat (Terminals A, B, C, D, E)');
    }
  };

  // Validation before step 1 -> 2
  const handleProceedToVehicles = () => {
    if (serviceType !== 'day_trip' && serviceType !== 'hourly') {
      if (!pickup || !pickup.trim()) {
        setErrorMsg('Please specify a valid pick-up location or terminal');
        return;
      }
      if (!dropoff || !dropoff.trim()) {
        setErrorMsg('Please specify a destination or drop-off location');
        return;
      }
    }
    if (!date) {
      setErrorMsg('Please select a travel date');
      return;
    }
    if (!time) {
      setErrorMsg('Please select a pickup time');
      return;
    }
    setErrorMsg('');
    setStep(2);
  };

  // Instant WhatsApp booking directly with current itinerary
  const openDirectWhatsAppBooking = () => {
    const tripDesc = serviceType === 'day_trip'
      ? DAY_TRIPS.find(t => t.id === selectedDayTripId)?.title || 'Catalonia Day Trip'
      : serviceType === 'hourly'
      ? `Hourly Chauffeur (${hours} Hours)`
      : `${pickup} → ${dropoff}`;

    const text = `*MR DRIVER Barcelona - WhatsApp Booking Inquiry*\n\n` +
      `Service: ${serviceType.toUpperCase()}\n` +
      `Trip: ${tripDesc}\n` +
      `Date & Time: ${date} at ${time}\n` +
      `Guests: ${passengers} | Luggage: ${luggage}\n` +
      `Vehicle: ${currentSelectedVehicle.name}\n` +
      (serviceType === 'airport' && flightNumber ? `Flight: ${flightNumber}\n` : '') +
      `\nPlease confirm availability and fixed quote.\n` +
      `Dispatch: Terminal 1 El Prat de Llobregat Barcelona | +34 662 524 244`;

    const url = `https://wa.me/34662524244?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  // Validation before step 3 -> 4
  const handleProceedToConfirmation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) {
      setErrorMsg('Please enter your full name');
      return;
    }
    if (!phone.trim()) {
      setErrorMsg('Please enter your contact phone / WhatsApp number');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMsg('Please enter a valid email address');
      return;
    }

    setErrorMsg('');

    // Generate reference code
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const refCode = `MRD-${randomSuffix}`;

    const newBooking: ActiveBookingRecord = {
      id: refCode,
      serviceType,
      pickupLocation: serviceType === 'day_trip' 
        ? `${pickup || 'Barcelona City Center Hotel / Residence'} (VIP Departure)` 
        : pickup,
      dropoffLocation: serviceType === 'day_trip'
        ? `${DAY_TRIPS.find(t => t.id === selectedDayTripId)?.title || 'Catalonia Day Trip'} (Roundtrip Tour)`
        : serviceType === 'hourly' ? `As directed within Barcelona (${hours} Hours)` : dropoff,
      date,
      time,
      hours: serviceType === 'hourly' ? hours : undefined,
      selectedDayTripId: serviceType === 'day_trip' ? selectedDayTripId : undefined,
      passengers,
      luggage,
      flightNumber: serviceType === 'airport' ? flightNumber : undefined,
      meetAndGreetName: serviceType === 'airport' ? meetAndGreetName : undefined,
      childSeat,
      boosterSeat,
      selectedVehicleId,
      fullName,
      email,
      phone,
      specialRequests,
      totalPriceEUR: currentTotalEUR,
      currency,
      bookingRef: refCode,
      status: 'confirmed',
      createdAt: new Date().toISOString(),
      chauffeur: {
        name: 'Alejandro Morales',
        phone: '+34 662 524 244',
        rating: 4.99,
        tripsCount: 1420,
        vehiclePlate: '9421-LMB',
        vehicleModel: currentSelectedVehicle.model,
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
        status: 'assigned',
      }
    };

    setConfirmedBooking(newBooking);
    onBookingConfirmed(newBooking);
    addBookingToUser(newBooking);
    setShowSuccessModal(true);
    setStep(4);
  };

  // Create WhatsApp message link
  const openWhatsAppConfirmation = () => {
    if (!confirmedBooking) return;
    const msg = `*MR DRIVER Barcelona - Booking Request*\n\n` +
      `Reference: ${confirmedBooking.bookingRef}\n` +
      `Guest Name: ${confirmedBooking.fullName}\n` +
      `Vehicle: ${currentSelectedVehicle.name}\n` +
      `Service: ${confirmedBooking.serviceType.toUpperCase()}\n` +
      `Date & Time: ${confirmedBooking.date} at ${confirmedBooking.time}\n` +
      `Pickup: ${confirmedBooking.pickupLocation}\n` +
      `Dropoff: ${confirmedBooking.dropoffLocation}\n` +
      (confirmedBooking.flightNumber ? `Flight: ${confirmedBooking.flightNumber}\n` : '') +
      `Passengers: ${confirmedBooking.passengers} | Luggage: ${confirmedBooking.luggage}\n` +
      `Total: ${formatPrice(confirmedBooking.totalPriceEUR)}\n\n` +
      `Please confirm my VIP chauffeur reservation.\n\n` +
      `Dispatch: Terminal 1 El Prat de Llobregat Barcelona | privatehire24h@gmail.com`;
    
    const url = `https://wa.me/34662524244?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  const copyBookingRef = () => {
    if (confirmedBooking?.bookingRef) {
      navigator.clipboard.writeText(confirmedBooking.bookingRef);
      setCopiedRef(true);
      setTimeout(() => setCopiedRef(false), 2000);
    }
  };

  return (
    <div id="booking-engine" className="w-full max-w-5xl mx-auto px-4 sm:px-6">
      <div className="bg-[#0b1322] border border-amber-500/20 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-xl">
        
        {/* Header Ribbon */}
        <div className="px-6 py-5 bg-gradient-to-r from-[#0d182b] via-[#111f38] to-[#0d182b] border-b border-slate-800 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-cinzel flex items-center gap-2">
              <span>Online Chauffeur Booking</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Instant guaranteed reservation with real-time flight tracking &amp; meet &amp; greet
            </p>
          </div>

          {/* Stepper Steps Indicators */}
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-[11px] sm:text-xs font-medium">
            <span className={`px-2.5 py-1 rounded-md transition-colors ${step >= 1 ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'}`}>
              1. Route
            </span>
            <span className="text-slate-600">→</span>
            <span className={`px-2.5 py-1 rounded-md transition-colors ${step >= 2 ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'}`}>
              2. Vehicle
            </span>
            <span className="text-slate-600">→</span>
            <span className={`px-2.5 py-1 rounded-md transition-colors ${step >= 3 ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'}`}>
              3. Guest Details
            </span>
            <span className="text-slate-600">→</span>
            <span className={`px-2.5 py-1 rounded-md transition-colors ${step === 4 ? 'bg-emerald-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'}`}>
              4. Pass
            </span>
          </div>
        </div>

        {/* STEP 1: ROUTE & SERVICE CONFIGURATION */}
        {step === 1 && (
          <div key="step-1" className="step-transition p-6 sm:p-8 space-y-6">
            {errorMsg && (
              <div className="p-3 bg-red-950/60 border border-red-500/50 rounded-xl text-xs text-red-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}
            
            {/* Service Type Tab Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-1.5 bg-slate-900/90 rounded-xl border border-slate-800">
              <button
                type="button"
                onClick={() => handleServiceChange('airport')}
                className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  serviceType === 'airport'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Plane className="w-4 h-4" />
                <span>Airport Pick-Up</span>
              </button>

              <button
                type="button"
                onClick={() => handleServiceChange('point_to_point')}
                className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  serviceType === 'point_to_point'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <MapPin className="w-4 h-4" />
                <span>City &amp; Port Transfer</span>
              </button>

              <button
                type="button"
                onClick={() => handleServiceChange('hourly')}
                className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  serviceType === 'hourly'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Clock className="w-4 h-4" />
                <span>Hourly Chauffeur</span>
              </button>

              <button
                type="button"
                onClick={() => handleServiceChange('day_trip')}
                className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  serviceType === 'day_trip'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Compass className="w-4 h-4" />
                <span>Day Trip Tours</span>
              </button>
            </div>

            {/* Airport Direction Toggle (if airport selected) */}
            {serviceType === 'airport' && (
              <div className="flex items-center gap-3 p-3 bg-slate-900/60 rounded-xl border border-slate-800/80 text-xs text-slate-300">
                <span className="font-medium text-slate-400">Transfer Direction:</span>
                <button
                  type="button"
                  onClick={() => {
                    setAirportMode('arrival');
                    setPickup('BCN Josep Tarradellas Airport - Terminal 1');
                    setDropoff('Hotel Arts Barcelona (The Ritz-Carlton)');
                  }}
                  className={`px-3 py-1.5 rounded-md font-medium cursor-pointer ${
                    airportMode === 'arrival' ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  Arrival (Airport → Hotel/City)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAirportMode('departure');
                    setPickup('Mandarin Oriental Barcelona');
                    setDropoff('BCN Josep Tarradellas Airport - Terminal 1');
                  }}
                  className={`px-3 py-1.5 rounded-md font-medium cursor-pointer ${
                    airportMode === 'departure' ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  Departure (City → Airport)
                </button>
              </div>
            )}

            {/* Curated Day Trip Package selector (if day_trip selected) */}
            {serviceType === 'day_trip' ? (
              <div className="space-y-3">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Select Curated Catalonia Day Trip
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {DAY_TRIPS.map((trip) => (
                    <div
                      key={trip.id}
                      onClick={() => setSelectedDayTripId(trip.id)}
                      className={`p-4 rounded-xl border cursor-pointer transition-all ${
                        selectedDayTripId === trip.id
                          ? 'border-amber-400 bg-amber-500/10'
                          : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-1">
                        <h4 className="font-semibold text-white text-sm">{trip.title}</h4>
                        <span className="text-amber-400 font-mono font-bold text-sm">
                          {formatPrice(trip.priceEUR)}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
                        <span>{trip.duration}</span>
                        <span>·</span>
                        <span>{trip.distance}</span>
                      </div>
                      <p className="text-xs text-slate-300 line-clamp-2">{trip.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            ) : serviceType === 'hourly' ? (
              /* Hourly duration */
              <div className="p-4 bg-slate-900/60 rounded-xl border border-slate-800 space-y-3">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
                  Chauffeur Disposal Duration
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[4, 6, 8, 12].map((h) => (
                    <button
                      key={h}
                      type="button"
                      onClick={() => setHours(h)}
                      className={`py-3 px-2 rounded-lg text-center cursor-pointer font-medium transition-all ${
                        hours === h
                          ? 'bg-amber-400 text-slate-950 font-bold shadow-md'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      <div className="text-sm">{h} Hours</div>
                      <div className="text-[10px] opacity-80">Included ~{h * 25} km</div>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              /* Pickup & Dropoff Inputs with Autocomplete Preset Dropdowns & Custom Typing */
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-amber-400" />
                      <span>Pick-Up Location *</span>
                    </span>
                    <span className="text-[10px] text-slate-400 lowercase font-normal">Type address or pick terminal</span>
                  </label>
                  <input
                    id="booking-pickup-input"
                    type="text"
                    list="pickup-locations-list"
                    value={pickup}
                    onChange={(e) => setPickup(e.target.value)}
                    placeholder="e.g. BCN Airport Terminal 1, Hotel Arts..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-3 text-sm text-white focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50"
                  />
                  <datalist id="pickup-locations-list">
                    {BARCELONA_LOCATIONS.map((loc) => (
                      <option key={loc.id} value={loc.name} />
                    ))}
                  </datalist>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-amber-400" />
                      <span>Drop-Off Destination *</span>
                    </span>
                    <span className="text-[10px] text-slate-400 lowercase font-normal">Type address or pick landmark</span>
                  </label>
                  <input
                    type="text"
                    list="dropoff-locations-list"
                    value={dropoff}
                    onChange={(e) => setDropoff(e.target.value)}
                    placeholder="e.g. Hotel Arts, Passeig de Gràcia, Port Moll Adossat..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-3 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                  <datalist id="dropoff-locations-list">
                    {BARCELONA_LOCATIONS.map((loc) => (
                      <option key={loc.id} value={loc.name} />
                    ))}
                  </datalist>
                </div>
              </div>
            )}

            {/* Date, Time, Passengers, Luggage */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-amber-400" />
                  <span>Date</span>
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Time</span>
                </label>
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-amber-400" />
                  <span>Guests</span>
                </label>
                <select
                  value={passengers}
                  onChange={(e) => setPassengers(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                >
                  {[1, 2, 3, 4, 5, 6, 7].map((n) => (
                    <option key={n} value={n}>
                      {n} {n === 1 ? 'Passenger' : 'Passengers'}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Briefcase className="w-3.5 h-3.5 text-amber-400" />
                  <span>Luggage</span>
                </label>
                <select
                  value={luggage}
                  onChange={(e) => setLuggage(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                >
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                    <option key={n} value={n}>
                      {n} Suitcases
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Flight info if airport */}
            {serviceType === 'airport' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-slate-900/50 rounded-xl border border-slate-800">
                <div className="space-y-1">
                  <label className="text-xs font-medium text-slate-300">
                    Incoming Flight Number (Live Radar Tracking)
                  </label>
                  <input
                    type="text"
                    value={flightNumber}
                    onChange={(e) => setFlightNumber(e.target.value)}
                    placeholder="e.g. IB2601 / BA482 / EK185"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                  <span className="text-[11px] text-slate-400">
                    Chauffeur automatically adjusts arrival time for flight delays at no extra fee.
                  </span>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-medium text-slate-300">
                    Meet &amp; Greet Tablet Nameboard
                  </label>
                  <input
                    type="text"
                    value={meetAndGreetName}
                    onChange={(e) => setMeetAndGreetName(e.target.value)}
                    placeholder="e.g. Mr. Alexander Wright / VIP Guest"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                  <span className="text-[11px] text-slate-400">
                    Chauffeur awaits inside arrival hall holding this personalized name.
                  </span>
                </div>
              </div>
            )}

            {/* Child seat add-ons */}
            <div className="flex flex-wrap items-center gap-6 pt-2 text-xs text-slate-300">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={childSeat}
                  onChange={(e) => setChildSeat(e.target.checked)}
                  className="rounded border-slate-700 text-amber-500 focus:ring-0 bg-slate-900"
                />
                <span>Child Safety Seat (+€15)</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={boosterSeat}
                  onChange={(e) => setBoosterSeat(e.target.checked)}
                  className="rounded border-slate-700 text-amber-500 focus:ring-0 bg-slate-900"
                />
                <span>Junior Booster Seat (+€10)</span>
              </label>
            </div>

            {/* Footer action to Step 2 & Instant WhatsApp Button */}
            <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
              <button
                type="button"
                onClick={openDirectWhatsAppBooking}
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600/90 hover:bg-emerald-500 text-white font-semibold text-xs shadow-md transition-all cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Book via WhatsApp (+34 662 524 244)</span>
              </button>

              <button
                type="button"
                onClick={handleProceedToVehicles}
                className="flex items-center justify-center gap-2 px-7 py-3 text-sm font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 rounded-xl transition-all shadow-md cursor-pointer"
              >
                <span>Continue to Vehicle Selection</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        )}

        {/* STEP 2: SELECT VEHICLE */}
        {step === 2 && (
          <div key="step-2" className="step-transition p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-white">Select Your Executive Vehicle</h3>
                <p className="text-xs text-slate-400">
                  Choose between our flagship Mercedes-Maybach, zero-emission Tesla Model 3 EV, Executive E-Class, or VIP V-Class Minivan.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setStep(1)}
                className="text-xs text-amber-400 hover:underline cursor-pointer"
              >
                ← Edit Route
              </button>
            </div>

            {/* Vehicle Options Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {FLEET_DATA.map((vehicle) => {
                const isSelected = selectedVehicleId === vehicle.id;
                const vehiclePrice = calculateVehiclePriceEUR(vehicle);

                return (
                  <div
                    key={vehicle.id}
                    onClick={() => setSelectedVehicleId(vehicle.id)}
                    className={`rounded-2xl border p-5 flex flex-col justify-between transition-all cursor-pointer relative overflow-hidden ${
                      isSelected
                        ? 'border-amber-400 bg-gradient-to-b from-amber-500/10 via-slate-900 to-[#0e172a] shadow-xl shadow-amber-500/10'
                        : 'border-slate-800 bg-slate-900/60 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    {isSelected && (
                      <div className="absolute top-3 right-3 bg-amber-400 text-slate-950 p-1 rounded-full shadow-md">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </div>
                    )}

                    <div>
                      {/* Vehicle image */}
                      <div className="h-36 w-full rounded-xl overflow-hidden mb-4 bg-slate-950">
                        <img
                          src={vehicle.image}
                          alt={vehicle.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      <div className="text-xs text-amber-400 font-semibold uppercase tracking-wider mb-0.5">
                        {vehicle.category}
                      </div>
                      <h4 className="text-base font-bold text-white mb-1">{vehicle.name}</h4>
                      <div className="text-xs text-slate-400 mb-3">{vehicle.model}</div>

                      {/* Capacity metrics */}
                      <div className="flex items-center gap-4 text-xs text-slate-300 py-2 border-y border-slate-800/80 mb-3">
                        <span className="flex items-center gap-1.5">
                          <Users className="w-3.5 h-3.5 text-amber-400" />
                          <span>Max {vehicle.passengers} Pax</span>
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Briefcase className="w-3.5 h-3.5 text-amber-400" />
                          <span>{vehicle.luggage} Bags</span>
                        </span>
                      </div>

                      {/* Features */}
                      <ul className="space-y-1.5 text-xs text-slate-400 mb-4">
                        {vehicle.features.slice(0, 3).map((feat, idx) => (
                          <li key={idx} className="flex items-center gap-1.5">
                            <span className="text-amber-400">✓</span>
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="text-[10px] text-slate-400 uppercase">Fixed Quote</div>
                        <div className="text-xl font-bold text-white font-mono tabular-nums">
                          {formatPrice(vehiclePrice)}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedVehicleId(vehicle.id);
                          setStep(3);
                        }}
                        className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                            : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                        }`}
                      >
                        Select &amp; Proceed
                      </button>
                    </div>

                  </div>
                );
              })}
            </div>

            {/* Back / Next actions */}
            <div className="pt-4 border-t border-slate-800 flex justify-between items-center">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-4 py-2.5 text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                ← Back to Route
              </button>

              <button
                type="button"
                onClick={() => setStep(3)}
                className="flex items-center gap-2 px-6 py-3 text-sm font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 rounded-xl transition-all shadow-md cursor-pointer"
              >
                <span>Continue with {currentSelectedVehicle.name}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        )}

        {/* STEP 3: PASSENGER & CONTACT DETAILS */}
        {step === 3 && (
          <form key="step-3" onSubmit={handleProceedToConfirmation} className="step-transition p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-white">Passenger &amp; Contact Details</h3>
                <p className="text-xs text-slate-400">
                  Your chauffeur coordinates directly via WhatsApp &amp; SMS prior to pick-up.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setStep(2)}
                className="text-xs text-amber-400 hover:underline cursor-pointer"
              >
                ← Change Vehicle
              </button>
            </div>

            {errorMsg && (
              <div className="p-3 bg-red-950/60 border border-red-500/50 rounded-xl text-xs text-red-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-amber-400" />
                  <span>Lead Passenger Full Name *</span>
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. David Sterling"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-amber-400" />
                  <span>Phone / WhatsApp Number *</span>
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+34 600 000 000 or +44 / +92"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-amber-400" />
                  <span>Email for Booking Confirmation &amp; Invoice *</span>
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="guest@example.com"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-amber-400" />
                  <span>Special VIP Requests (Optional)</span>
                </label>
                <textarea
                  rows={2}
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  placeholder="e.g. Specific beverage preferences, extra luggage assistance, quiet ride, preferred drop-off lobby..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            {/* Ride Summary Quick Box */}
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-2">
              <div className="flex justify-between items-center text-slate-400 border-b border-slate-800/80 pb-2">
                <span>Selected Vehicle:</span>
                <span className="font-semibold text-white">{currentSelectedVehicle.name}</span>
              </div>
              <div className="flex justify-between items-center text-slate-400 border-b border-slate-800/80 pb-2">
                <span>Schedule:</span>
                <span className="text-white">{date} at {time}</span>
              </div>
              <div className="flex justify-between items-center text-slate-400 border-b border-slate-800/80 pb-2">
                <span>Trip:</span>
                <span className="text-white text-right max-w-xs truncate">
                  {serviceType === 'day_trip' 
                    ? DAY_TRIPS.find(t => t.id === selectedDayTripId)?.title 
                    : `${pickup} → ${dropoff}`}
                </span>
              </div>
              <div className="flex justify-between items-center pt-1 text-sm">
                <span className="font-bold text-white">Guaranteed Fixed Total:</span>
                <span className="text-amber-400 font-bold font-mono text-base">
                  {formatPrice(currentTotalEUR)}
                </span>
              </div>
            </div>

            {/* Submit & Confirm */}
            <div className="pt-4 border-t border-slate-800 flex justify-between items-center">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="px-4 py-2.5 text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                ← Back
              </button>

              <button
                type="submit"
                className="flex items-center gap-2 px-8 py-3.5 text-sm font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 rounded-xl shadow-lg shadow-amber-500/25 transition-all cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Confirm Reservation</span>
              </button>
            </div>
          </form>
        )}

        {/* STEP 4: DIGITAL BOOKING VOUCHER & DISPATCH */}
        {step === 4 && confirmedBooking && (
          <div key="step-4" className="step-transition p-6 sm:p-8 space-y-6">
            
            {/* Success Banner */}
            <div className="text-center space-y-2 py-4 border-b border-slate-800">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 mb-1">
                <Check className="w-6 h-6 stroke-[3]" />
              </div>
              <h3 className="text-2xl font-bold text-white font-cinzel">Booking Confirmed</h3>
              <p className="text-xs sm:text-sm text-slate-300">
                Your luxury transfer with MR DRIVER Barcelona has been successfully scheduled.
              </p>
              
              {/* Reference badge */}
              <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-slate-900 border border-amber-500/40 rounded-lg text-sm text-amber-400 font-mono font-bold mt-2">
                <span>Ref: {confirmedBooking.bookingRef}</span>
                <button
                  type="button"
                  onClick={copyBookingRef}
                  className="text-slate-400 hover:text-white cursor-pointer"
                  title="Copy Reference"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
                {copiedRef && <span className="text-[10px] text-emerald-400">Copied!</span>}
              </div>
            </div>

            {/* Voucher Details Card */}
            <div className="bg-slate-950/80 rounded-2xl border border-slate-800 p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-slate-500 block uppercase tracking-wider text-[10px]">Passenger</span>
                  <span className="text-white font-medium text-sm">{confirmedBooking.fullName}</span>
                  <span className="text-slate-400 block">{confirmedBooking.phone}</span>
                </div>

                <div>
                  <span className="text-slate-500 block uppercase tracking-wider text-[10px]">Vehicle Assigned</span>
                  <span className="text-white font-medium text-sm">{currentSelectedVehicle.name}</span>
                  <span className="text-slate-400 block">{currentSelectedVehicle.model}</span>
                </div>

                <div>
                  <span className="text-slate-500 block uppercase tracking-wider text-[10px]">Pick-Up Schedule</span>
                  <span className="text-white font-medium text-sm">{confirmedBooking.date} at {confirmedBooking.time}</span>
                  {confirmedBooking.flightNumber && (
                    <span className="text-amber-400 block">Flight: {confirmedBooking.flightNumber}</span>
                  )}
                </div>

                <div>
                  <span className="text-slate-500 block uppercase tracking-wider text-[10px]">Total Guaranteed Fare</span>
                  <span className="text-amber-400 font-mono font-bold text-base">
                    {formatPrice(confirmedBooking.totalPriceEUR)}
                  </span>
                  <span className="text-slate-500 block text-[10px]">All tolls, fuel &amp; meet-greet included</span>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800/80 text-xs">
                <span className="text-slate-500 block uppercase tracking-wider text-[10px] mb-1">Route</span>
                <div className="space-y-1 text-slate-300">
                  <div className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">From:</span>
                    <span>{confirmedBooking.pickupLocation}</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-amber-400 font-bold">To:</span>
                    <span>{confirmedBooking.dropoffLocation}</span>
                  </div>
                </div>
              </div>

              {/* Chauffeur On-Duty Box */}
              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-800 border border-amber-500/40 flex items-center justify-center text-amber-400 font-bold">
                    AM
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span>{confirmedBooking.chauffeur.name}</span>
                      <span className="text-[10px] text-amber-400">★ {confirmedBooking.chauffeur.rating}</span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Senior Executive Chauffeur · Plate {confirmedBooking.chauffeur.vehiclePlate}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onOpenTracker}
                  className="px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700 rounded-lg cursor-pointer"
                >
                  Live Chauffeur Radar
                </button>
              </div>

            </div>

            {/* Direct Instant Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center gap-3">
              <button
                type="button"
                onClick={onOpenTracker}
                className="w-full sm:w-auto py-3 px-4 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
              >
                <span>View My Ride Status</span>
              </button>

              <button
                type="button"
                onClick={openWhatsAppConfirmation}
                className="w-full sm:flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/30 transition-all cursor-pointer"
              >
                <span>Dispatch to WhatsApp</span>
              </button>

              <button
                type="button"
                onClick={() => setShowSuccessModal(true)}
                className="w-full sm:w-auto py-3 px-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-medium rounded-xl flex items-center justify-center gap-2 border border-slate-700 cursor-pointer"
              >
                <span>Summary Modal</span>
              </button>

              <button
                type="button"
                onClick={() => window.print()}
                className="w-full sm:w-auto py-3 px-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-medium rounded-xl flex items-center justify-center gap-2 border border-slate-700 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setStep(1);
                  setConfirmedBooking(null);
                }}
                className="w-full sm:w-auto py-3 px-4 text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                Book Another Ride
              </button>
            </div>

          </div>
        )}

      </div>

      {/* Immediate Booking Success Modal */}
      <BookingSuccessModal
        isOpen={showSuccessModal}
        onClose={() => setShowSuccessModal(false)}
        booking={confirmedBooking}
        currency={currency}
        onOpenTracker={onOpenTracker}
      />
    </div>
  );
};
