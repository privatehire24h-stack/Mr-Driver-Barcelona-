export type ServiceType = 'airport' | 'point_to_point' | 'hourly' | 'day_trip';

export type Currency = 'EUR' | 'USD' | 'GBP';

export interface Vehicle {
  id: string;
  name: string;
  category: string;
  model: string;
  description: string;
  passengers: number;
  luggage: number;
  basePriceEUR: number;
  perKmRateEUR: number;
  hourlyRateEUR: number;
  image: string;
  features: string[];
}

export interface DayTrip {
  id: string;
  title: string;
  duration: string;
  distance: string;
  highlights: string[];
  description: string;
  priceEUR: number;
  image: string;
}

export interface BookingDetails {
  serviceType: ServiceType;
  pickupLocation: string;
  dropoffLocation: string;
  date: string;
  time: string;
  hours?: number;
  selectedDayTripId?: string;
  passengers: number;
  luggage: number;
  flightNumber?: string;
  meetAndGreetName?: string;
  childSeat: boolean;
  boosterSeat: boolean;
  selectedVehicleId: string;
  fullName: string;
  email: string;
  phone: string;
  specialRequests?: string;
  totalPriceEUR: number;
  currency: Currency;
  bookingRef?: string;
  status?: 'confirmed' | 'assigned' | 'en_route' | 'completed' | 'cancelled';
}

export interface ActiveBookingRecord extends BookingDetails {
  id: string;
  createdAt: string;
  chauffeur: {
    name: string;
    phone: string;
    rating: number;
    tripsCount: number;
    vehiclePlate: string;
    vehicleModel: string;
    avatar: string;
    status: 'assigned' | 'approaching' | 'waiting_arrival' | 'in_transit';
  };
}
