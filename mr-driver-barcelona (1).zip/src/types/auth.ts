import { ActiveBookingRecord, Currency } from './booking';

export interface CreditTransaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'earned' | 'redeemed';
  bookingRef?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  preferredCurrency: Currency;
  preferredVehicle?: string;
  defaultPickupAddress?: string;
  createdAt: string;
  chauffeurCredits: number;
  loyaltyTier: 'Silver' | 'Gold' | 'Platinum';
  creditHistory: CreditTransaction[];
}

export interface UserAccount extends UserProfile {
  passwordHash: string; // Stored locally
}

export type AuthModalView = 'login' | 'signup' | 'forgot_password' | 'reset_code';
