import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserAccount, CreditTransaction } from '../types/auth';
import { ActiveBookingRecord, Currency } from '../types/booking';

interface AuthContextType {
  user: UserProfile | null;
  isAuthenticated: boolean;
  bookings: ActiveBookingRecord[];
  login: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  signup: (name: string, email: string, phone: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateProfile: (updated: Partial<UserProfile>) => Promise<{ success: boolean; error?: string }>;
  changePassword: (oldPass: string, newPass: string) => Promise<{ success: boolean; error?: string }>;
  requestPasswordReset: (email: string) => Promise<{ success: boolean; code?: string; error?: string }>;
  confirmPasswordReset: (email: string, code: string, newPass: string) => Promise<{ success: boolean; error?: string }>;
  addBookingToUser: (booking: ActiveBookingRecord) => void;
  completeUserBooking: (bookingId: string) => void;
  cancelUserBooking: (bookingId: string) => void;
  updateBookingStatus: (
    bookingId: string,
    status: 'confirmed' | 'assigned' | 'en_route' | 'completed' | 'cancelled',
    chauffeurStatus?: 'assigned' | 'approaching' | 'waiting_arrival' | 'in_transit'
  ) => void;
  redeemCredits: (creditsToRedeem: number) => { success: boolean; discountEUR: number; error?: string };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Initial Demo Seed Account with Earned Chauffeur Credits
const DEMO_ACCOUNT: UserAccount = {
  id: 'usr-demo-001',
  name: 'David Sterling',
  email: 'd.sterling@example.com',
  phone: '+34 612 000 111',
  preferredCurrency: 'EUR',
  preferredVehicle: 'first-class-maybach',
  defaultPickupAddress: 'BCN Josep Tarradellas Airport - Terminal 1',
  createdAt: '2026-08-10T10:00:00.000Z',
  passwordHash: 'password123',
  chauffeurCredits: 320,
  loyaltyTier: 'Gold',
  creditHistory: [
    {
      id: 'tx-demo-1',
      date: '2026-09-18',
      description: 'Completed Montserrat Royal Sanctuary Tour (MRD-61024)',
      amount: 320,
      type: 'earned',
      bookingRef: 'MRD-61024',
    },
  ],
};

// Initial Seed Bookings
const SEED_BOOKINGS: ActiveBookingRecord[] = [
  {
    id: 'MRD-84920',
    bookingRef: 'MRD-84920',
    serviceType: 'airport',
    pickupLocation: 'BCN Josep Tarradellas Airport - Terminal 1 (Arrivals)',
    dropoffLocation: 'Hotel Arts Barcelona (The Ritz-Carlton)',
    date: 'Tomorrow',
    time: '14:30',
    passengers: 2,
    luggage: 2,
    flightNumber: 'IB2601',
    meetAndGreetName: 'David Sterling',
    childSeat: false,
    boosterSeat: false,
    selectedVehicleId: 'first-class-maybach',
    fullName: 'David Sterling',
    email: 'd.sterling@example.com',
    phone: '+34 612 000 111',
    totalPriceEUR: 130,
    currency: 'EUR',
    createdAt: new Date().toISOString(),
    status: 'assigned',
    chauffeur: {
      name: 'Alejandro Morales',
      phone: '+34 612 345 678',
      rating: 4.99,
      tripsCount: 1420,
      vehiclePlate: '9421-LMB',
      vehicleModel: 'Mercedes-Maybach S 580',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
      status: 'waiting_arrival',
    }
  },
  {
    id: 'MRD-61024',
    bookingRef: 'MRD-61024',
    serviceType: 'day_trip',
    pickupLocation: 'Mandarin Oriental Barcelona',
    dropoffLocation: 'Montserrat Royal Sanctuary & Monastery (Roundtrip)',
    date: '2026-09-18',
    time: '09:00',
    hours: 6,
    passengers: 4,
    luggage: 2,
    childSeat: false,
    boosterSeat: false,
    selectedVehicleId: 'vip-van-vclass',
    fullName: 'David Sterling',
    email: 'd.sterling@example.com',
    phone: '+34 612 000 111',
    totalPriceEUR: 320,
    currency: 'EUR',
    createdAt: '2026-09-18T09:00:00.000Z',
    status: 'completed',
    chauffeur: {
      name: 'Carlos Mendez',
      phone: '+34 618 992 104',
      rating: 4.98,
      tripsCount: 980,
      vehiclePlate: '4820-KPT',
      vehicleModel: 'Mercedes-Benz V-Class Avantgarde',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
      status: 'in_transit',
    }
  }
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const stored = localStorage.getItem('mr_driver_user_session');
      return stored ? JSON.parse(stored) : DEMO_ACCOUNT;
    } catch {
      return DEMO_ACCOUNT;
    }
  });

  const [bookings, setBookings] = useState<ActiveBookingRecord[]>(() => {
    try {
      const stored = localStorage.getItem('mr_driver_user_bookings');
      return stored ? JSON.parse(stored) : SEED_BOOKINGS;
    } catch {
      return SEED_BOOKINGS;
    }
  });

  // Sync session and bookings to localStorage
  useEffect(() => {
    if (user) {
      localStorage.setItem('mr_driver_user_session', JSON.stringify(user));
    } else {
      localStorage.removeItem('mr_driver_user_session');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('mr_driver_user_bookings', JSON.stringify(bookings));
  }, [bookings]);

  // Registry of accounts
  const getAccounts = (): UserAccount[] => {
    try {
      const stored = localStorage.getItem('mr_driver_accounts_registry');
      if (!stored) {
        localStorage.setItem('mr_driver_accounts_registry', JSON.stringify([DEMO_ACCOUNT]));
        return [DEMO_ACCOUNT];
      }
      return JSON.parse(stored);
    } catch {
      return [DEMO_ACCOUNT];
    }
  };

  const saveAccounts = (accounts: UserAccount[]) => {
    localStorage.setItem('mr_driver_accounts_registry', JSON.stringify(accounts));
  };

  // Sign in
  const login = async (email: string, pass: string): Promise<{ success: boolean; error?: string }> => {
    const accounts = getAccounts();
    const cleanEmail = email.trim().toLowerCase();
    const found = accounts.find(a => a.email.toLowerCase() === cleanEmail);

    if (!found) {
      return { success: false, error: 'No account found with this email address.' };
    }

    if (found.passwordHash !== pass) {
      return { success: false, error: 'Incorrect password. Please try again or reset your password.' };
    }

    const { passwordHash: _, ...profile } = found;
    setUser(profile);
    return { success: true };
  };

  // Sign up
  const signup = async (
    name: string,
    email: string,
    phone: string,
    pass: string
  ): Promise<{ success: boolean; error?: string }> => {
    const accounts = getAccounts();
    const cleanEmail = email.trim().toLowerCase();

    if (accounts.some(a => a.email.toLowerCase() === cleanEmail)) {
      return { success: false, error: 'An account with this email already exists. Please log in.' };
    }

    if (pass.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters long.' };
    }

    const newAccount: UserAccount = {
      id: `usr-${Date.now().toString(36)}`,
      name: name.trim(),
      email: cleanEmail,
      phone: phone.trim(),
      preferredCurrency: 'EUR',
      createdAt: new Date().toISOString(),
      passwordHash: pass,
      chauffeurCredits: 100, // 100 Welcome Credits for new members!
      loyaltyTier: 'Silver',
      creditHistory: [
        {
          id: `tx-welcome-${Date.now()}`,
          date: new Date().toISOString().split('T')[0],
          description: 'Welcome Bonus Credits (VIP Club Registration)',
          amount: 100,
          type: 'earned',
        },
      ],
    };

    saveAccounts([...accounts, newAccount]);

    const { passwordHash: _, ...profile } = newAccount;
    setUser(profile);
    return { success: true };
  };

  const logout = () => {
    setUser(null);
  };

  const updateProfile = async (updated: Partial<UserProfile>): Promise<{ success: boolean; error?: string }> => {
    if (!user) return { success: false, error: 'Not authenticated' };

    const accounts = getAccounts();
    const index = accounts.findIndex(a => a.id === user.id);
    if (index === -1) return { success: false, error: 'Account not found' };

    const updatedAccount = { ...accounts[index], ...updated };
    accounts[index] = updatedAccount;
    saveAccounts(accounts);

    const { passwordHash: _, ...profile } = updatedAccount;
    setUser(profile);
    return { success: true };
  };

  const changePassword = async (oldPass: string, newPass: string): Promise<{ success: boolean; error?: string }> => {
    if (!user) return { success: false, error: 'Not authenticated' };
    const accounts = getAccounts();
    const index = accounts.findIndex(a => a.id === user.id);
    if (index === -1) return { success: false, error: 'Account not found' };

    if (accounts[index].passwordHash !== oldPass) {
      return { success: false, error: 'Current password does not match.' };
    }

    if (newPass.length < 6) {
      return { success: false, error: 'New password must be at least 6 characters.' };
    }

    accounts[index].passwordHash = newPass;
    saveAccounts(accounts);
    return { success: true };
  };

  // Password reset simulation
  const requestPasswordReset = async (email: string): Promise<{ success: boolean; code?: string; error?: string }> => {
    const accounts = getAccounts();
    const cleanEmail = email.trim().toLowerCase();
    const found = accounts.find(a => a.email.toLowerCase() === cleanEmail);
    if (!found) {
      return { success: false, error: 'No account registered with this email address.' };
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    sessionStorage.setItem(`mr_reset_${cleanEmail}`, code);
    return { success: true, code };
  };

  const confirmPasswordReset = async (
    email: string,
    code: string,
    newPass: string
  ): Promise<{ success: boolean; error?: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    const savedCode = sessionStorage.getItem(`mr_reset_${cleanEmail}`);

    if (!savedCode || savedCode !== code.trim()) {
      return { success: false, error: 'Invalid or expired 6-digit verification code.' };
    }

    if (newPass.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters long.' };
    }

    const accounts = getAccounts();
    const index = accounts.findIndex(a => a.id === cleanEmail);
    if (index === -1) {
      // Find by email
      const byEmail = accounts.findIndex(a => a.email.toLowerCase() === cleanEmail);
      if (byEmail === -1) return { success: false, error: 'Account not found' };
      accounts[byEmail].passwordHash = newPass;
      saveAccounts(accounts);
    } else {
      accounts[index].passwordHash = newPass;
      saveAccounts(accounts);
    }

    sessionStorage.removeItem(`mr_reset_${cleanEmail}`);
    return { success: true };
  };

  // Add booking to user profile list
  const addBookingToUser = (booking: ActiveBookingRecord) => {
    setBookings(prev => [booking, ...prev]);
  };

  const cancelUserBooking = (bookingId: string) => {
    setBookings(prev =>
      prev.map(b => (b.id === bookingId ? { ...b, status: 'completed' as const } : b))
    );
  };

  const updateBookingStatus = (
    bookingId: string,
    status: 'confirmed' | 'assigned' | 'en_route' | 'completed' | 'cancelled',
    chauffeurStatus?: 'assigned' | 'approaching' | 'waiting_arrival' | 'in_transit'
  ) => {
    setBookings(prev =>
      prev.map(b => {
        if (b.id === bookingId || b.bookingRef === bookingId) {
          return {
            ...b,
            status,
            chauffeur: {
              ...b.chauffeur,
              status: chauffeurStatus || (
                status === 'en_route' ? 'approaching' :
                status === 'assigned' ? 'waiting_arrival' :
                status === 'completed' ? 'in_transit' : b.chauffeur.status
              ),
            },
          };
        }
        return b;
      })
    );
  };

  // Complete a booking and award 1 credit per €1 spent
  const completeUserBooking = (bookingId: string) => {
    const booking = bookings.find(b => b.id === bookingId);
    if (!booking) return;

    // Update booking status
    setBookings(prev =>
      prev.map(b => (b.id === bookingId ? { ...b, status: 'completed' as const } : b))
    );

    // Award credits to active user
    if (user) {
      const creditsEarned = Math.round(booking.totalPriceEUR);
      const newTotal = (user.chauffeurCredits || 0) + creditsEarned;
      const newTier = newTotal >= 500 ? 'Platinum' : newTotal >= 200 ? 'Gold' : 'Silver';

      const newTx: CreditTransaction = {
        id: `tx-earned-${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        description: `Completed Transfer (${booking.bookingRef})`,
        amount: creditsEarned,
        type: 'earned',
        bookingRef: booking.bookingRef,
      };

      updateProfile({
        chauffeurCredits: newTotal,
        loyaltyTier: newTier,
        creditHistory: [newTx, ...(user.creditHistory || [])],
      });
    }
  };

  // Redeem Chauffeur Credits (10 credits = 1 EUR discount)
  const redeemCredits = (creditsToRedeem: number): { success: boolean; discountEUR: number; error?: string } => {
    if (!user) return { success: false, discountEUR: 0, error: 'Not authenticated' };
    if ((user.chauffeurCredits || 0) < creditsToRedeem) {
      return { success: false, discountEUR: 0, error: 'Insufficient Chauffeur Credits' };
    }

    const discountEUR = Math.round((creditsToRedeem / 10) * 100) / 100;
    const remaining = (user.chauffeurCredits || 0) - creditsToRedeem;

    const newTx: CreditTransaction = {
      id: `tx-redeem-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      description: `Redeemed ${creditsToRedeem} Credits for €${discountEUR} Fare Discount`,
      amount: creditsToRedeem,
      type: 'redeemed',
    };

    updateProfile({
      chauffeurCredits: remaining,
      creditHistory: [newTx, ...(user.creditHistory || [])],
    });

    return { success: true, discountEUR };
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        bookings,
        login,
        signup,
        logout,
        updateProfile,
        changePassword,
        requestPasswordReset,
        confirmPasswordReset,
        addBookingToUser,
        cancelUserBooking,
        completeUserBooking,
        updateBookingStatus,
        redeemCredits,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
