export interface LocationPreset {
  id: string;
  name: string;
  type: 'airport' | 'port' | 'hotel' | 'landmark' | 'city';
  address: string;
  distanceFromCenterKm: number;
}

export const BARCELONA_LOCATIONS: LocationPreset[] = [
  // Airports
  {
    id: 'bcn-t1',
    name: 'BCN Josep Tarradellas Airport - Terminal 1',
    type: 'airport',
    address: '08820 El Prat de Llobregat, Barcelona',
    distanceFromCenterKm: 16
  },
  {
    id: 'bcn-t2',
    name: 'BCN Josep Tarradellas Airport - Terminal 2',
    type: 'airport',
    address: '08820 El Prat de Llobregat, Barcelona',
    distanceFromCenterKm: 14
  },
  {
    id: 'gro-airport',
    name: 'Girona-Costa Brava Airport (GRO)',
    type: 'airport',
    address: '17185 Vilobí d\'Onyar, Girona',
    distanceFromCenterKm: 92
  },

  // Cruise Ports
  {
    id: 'port-moll-adossat',
    name: 'Port de Barcelona - Moll Adossat (Terminals A, B, C, D, E)',
    type: 'port',
    address: 'Moll Adossat, s/n, 08039 Barcelona',
    distanceFromCenterKm: 5
  },
  {
    id: 'port-world-trade',
    name: 'Port de Barcelona - World Trade Center Cruise Terminal',
    type: 'port',
    address: 'Moll de Barcelona, s/n, 08039 Barcelona',
    distanceFromCenterKm: 3
  },

  // Luxury 5-Star Hotels
  {
    id: 'hotel-arts',
    name: 'Hotel Arts Barcelona (The Ritz-Carlton)',
    type: 'hotel',
    address: 'Carrer de la Marina, 19-21, 08005 Barcelona',
    distanceFromCenterKm: 3
  },
  {
    id: 'hotel-w',
    name: 'W Barcelona (Sail Hotel)',
    type: 'hotel',
    address: 'Plaça Rosa Del Vents 1, Final Passeig de Joan de Borbó, 08039 Barcelona',
    distanceFromCenterKm: 4
  },
  {
    id: 'hotel-mandarin',
    name: 'Mandarin Oriental Barcelona',
    type: 'hotel',
    address: 'Passeig de Gràcia, 38-40, 08007 Barcelona',
    distanceFromCenterKm: 1
  },
  {
    id: 'hotel-majestic',
    name: 'Majestic Hotel & Spa Barcelona GL',
    type: 'hotel',
    address: 'Passeig de Gràcia, 68, 08007 Barcelona',
    distanceFromCenterKm: 1.2
  },
  {
    id: 'hotel-cotton-house',
    name: 'Cotton House Hotel, Autograph Collection',
    type: 'hotel',
    address: 'Gran Via de les Corts Catalanes, 670, 08010 Barcelona',
    distanceFromCenterKm: 0.8
  },
  {
    id: 'hotel-el-palace',
    name: 'El Palace Hotel Barcelona',
    type: 'hotel',
    address: 'Gran Via de les Corts Catalanes, 668, 08010 Barcelona',
    distanceFromCenterKm: 0.8
  },

  // Iconic Landmarks & Areas
  {
    id: 'sagrada-familia',
    name: 'Basílica de la Sagrada Família',
    type: 'landmark',
    address: 'Carrer de Mallorca, 401, 08013 Barcelona',
    distanceFromCenterKm: 2.5
  },
  {
    id: 'passeig-de-gracia',
    name: 'Passeig de Gràcia / Casa Batlló & La Pedrera',
    type: 'landmark',
    address: 'Passeig de Gràcia, 08007 Barcelona',
    distanceFromCenterKm: 1
  },
  {
    id: 'camp-nou',
    name: 'Spotify Camp Nou / FC Barcelona Stadium',
    type: 'landmark',
    address: 'Carrer d\'Arístides Maillol, 12, 08028 Barcelona',
    distanceFromCenterKm: 5
  },
  {
    id: 'fira-gran-via',
    name: 'Fira Barcelona Gran Via (MWC / Congress)',
    type: 'landmark',
    address: 'Av. Joan Carles I, 64, 08908 L\'Hospitalet de Llobregat',
    distanceFromCenterKm: 7
  },
  {
    id: 'montserrat',
    name: 'Montserrat Royal Sanctuary & Monastery',
    type: 'landmark',
    address: '08199 Montserrat, Barcelona',
    distanceFromCenterKm: 54
  },
  {
    id: 'sitges',
    name: 'Sitges Historic Coastal Center',
    type: 'city',
    address: '08870 Sitges, Barcelona',
    distanceFromCenterKm: 42
  },
  {
    id: 'andorra-la-vella',
    name: 'Andorra la Vella / Pyrenees (Tax-Free & Caldea)',
    type: 'city',
    address: 'AD500 Andorra la Vella, Principality of Andorra',
    distanceFromCenterKm: 200
  },
  {
    id: 'empuriabrava-marina',
    name: 'Empuriabrava Marina (Venice of Spain - Costa Brava)',
    type: 'city',
    address: 'Sector Club Nàutic, 17487 Empuriabrava, Girona',
    distanceFromCenterKm: 152
  },
  {
    id: 'lloret-de-mar',
    name: 'Lloret de Mar (Santa Clotilde & Costa Brava Beaches)',
    type: 'city',
    address: 'Passeig de Cinto Verdaguer, 17310 Lloret de Mar, Girona',
    distanceFromCenterKm: 76
  },
  {
    id: 'salou-portaventura',
    name: 'Salou & PortAventura World (Costa Daurada)',
    type: 'city',
    address: 'Passeig de Jaume I, 43840 Salou, Tarragona',
    distanceFromCenterKm: 110
  }
];
