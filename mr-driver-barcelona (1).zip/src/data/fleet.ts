import { Vehicle } from '../types/booking';

export const FLEET_DATA: Vehicle[] = [
  {
    id: 'mercedes-e-class',
    name: 'Mercedes-Benz E-Class',
    category: 'Executive Sedan',
    model: 'Mercedes-Benz E-Class AMG Line (Executive Chauffeur)',
    description: 'The European gold standard for executive airport transfers and corporate travel. Pristine black finish, quiet cabin, dual-zone climate control, and smooth air suspension.',
    passengers: 3,
    luggage: 2,
    basePriceEUR: 85,
    perKmRateEUR: 2.6,
    hourlyRateEUR: 80,
    image: '/src/assets/images/fleet_mercedes_eclass_1792560489487.jpg',
    features: [
      'Executive Leather Seating & Dual Climate Control',
      'Complimentary Bottled Mineral Water & Mints',
      'Device USB-C Rapid Charging & Wi-Fi',
      'Flight Delay Monitoring (60 Min Free Waiting)',
      'Meet & Greet at Terminal 1 & 2 Arrival Gate'
    ]
  },
  {
    id: 'mercedes-s-class',
    name: 'Mercedes-Benz S-Class',
    category: 'First Class Luxury Sedan',
    model: 'Mercedes-Benz S-Class Long Wheelbase (S 450 / S 500)',
    description: 'The pinnacle of luxury automotive engineering. Reclining heated & ventilated rear seats, Burmester 3D surround sound, acoustic double glazing, and chauffeur privacy blinds.',
    passengers: 3,
    luggage: 2,
    basePriceEUR: 125,
    perKmRateEUR: 3.4,
    hourlyRateEUR: 115,
    image: '/src/assets/images/fleet_mercedes_sclass_1792560505572.jpg',
    features: [
      'First-Class Executive Reclining Rear Seats',
      'Acoustic Privacy Glass & Electronic Sunshades',
      'Chilled Still & Sparkling Water Selection',
      'Onboard Wi-Fi & Tablet Concierge Access',
      'Senior Suited Chauffeur with 10+ Years Experience'
    ]
  },
  {
    id: 'mercedes-v-class',
    name: 'Mercedes-Benz V-Class',
    category: 'VIP Minivan (7 Passengers)',
    model: 'Mercedes-Benz V-Class Extra Long (Avantgarde)',
    description: 'Unmatched spacious luxury for families, VIP delegations, and luggage-heavy transfers. Features conference face-to-face seating, generous headroom, and enormous trunk volume.',
    passengers: 7,
    luggage: 7,
    basePriceEUR: 110,
    perKmRateEUR: 3.2,
    hourlyRateEUR: 105,
    image: '/src/assets/images/fleet_mercedes_vclass_1792560520653.jpg',
    features: [
      '7 Individual Luxury Leather Captain Chairs',
      'Conference Face-to-Face Meeting Setup',
      'Massive Luggage Capacity (Up to 7 Large Bags)',
      'Child & Booster Seats Provided Upon Request',
      'Rear Independent Passenger Climate Controls'
    ]
  },
  {
    id: 'tesla-model-3',
    name: 'Tesla Model 3 Long Range',
    category: '100% Electric Eco VIP',
    model: 'Tesla Model 3 Long Range AWD (Etiqueta CERO)',
    description: 'Whisper-quiet, 100% emission-free executive travel with full panoramic acoustic glass roof, premium minimalist cabin, and priority access to Barcelona low-emission environmental zones.',
    passengers: 3,
    luggage: 2,
    basePriceEUR: 75,
    perKmRateEUR: 2.4,
    hourlyRateEUR: 70,
    image: '/src/assets/images/fleet_tesla_model3_1792078482410.jpg',
    features: [
      '100% Zero-Emission Eco Ride (Etiqueta CERO)',
      'Full Panoramic Acoustic Tinted Glass Roof',
      'Whisper-Quiet Electric Smooth Acceleration',
      'Wireless Multi-Phone Charging Pads',
      'Priority Bus-VAO Lane Access for Faster Transit'
    ]
  },
  {
    id: 'first-class-maybach',
    name: 'Mercedes-Maybach S-Class',
    category: 'Presidential Ultra VIP',
    model: 'Mercedes-Maybach S 580 4MATIC (Executive Suite)',
    description: 'The supreme expression of prestige. Handcrafted diamond-quilted Nappa leather, rear footrests, ambient champagne illumination, and uncompromised discretion for dignitaries.',
    passengers: 3,
    luggage: 2,
    basePriceEUR: 160,
    perKmRateEUR: 4.2,
    hourlyRateEUR: 150,
    image: '/src/assets/images/fleet_maybach_luxury_1792076007808.jpg',
    features: [
      'Presidential Ottoman Reclining Suite with Calf Rest',
      'Hot Stone Massage Function in Rear Seats',
      'High-Grade Active Noise Cancellation',
      'Champagne Flutes & Refreshment Console',
      'Discreet Security-Trained Chauffeur'
    ]
  }
];
