/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Currency, ActiveBookingRecord } from './types/booking';
import { AuthProvider } from './context/AuthContext';
import { Header } from './components/Header';
import { BookingEngine } from './components/BookingEngine';
import { FleetSection } from './components/FleetSection';
import { DayTripsSection } from './components/DayTripsSection';
import { RatesTable } from './components/RatesTable';
import { VipBenefits } from './components/VipBenefits';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { RideTrackerModal } from './components/RideTrackerModal';
import { WhatsAppFloating } from './components/WhatsAppFloating';
import { PWAInstallButton } from './components/pwa/PWAInstallButton';
import { OfflineIndicator } from './components/pwa/OfflineIndicator';
import { CompactHub } from './components/CompactHub';
import { DriverPanel } from './components/DriverPanel';

function AppContent() {
  const [currency, setCurrency] = useState<Currency>('EUR');
  const [isTrackerOpen, setIsTrackerOpen] = useState(false);
  const [activeBooking, setActiveBooking] = useState<ActiveBookingRecord | null>(null);

  // Two Core Portals: Rider Portal & Driver Dispatch Panel
  const [panelMode, setPanelMode] = useState<'rider' | 'driver'>('rider');

  // Tab & View States: Clean, single-screen friendly app view
  const [activeTab, setActiveTab] = useState<'book' | 'fleet' | 'trips' | 'about' | 'contact'>('book');

  // Preset selections passed to booking engine
  const [selectedVehiclePreset, setSelectedVehiclePreset] = useState<string | null>(null);
  const [selectedDayTripPreset, setSelectedDayTripPreset] = useState<string | null>(null);
  const [selectedPickupPreset, setSelectedPickupPreset] = useState<string | null>(null);
  const [selectedDropoffPreset, setSelectedDropoffPreset] = useState<string | null>(null);
  const [selectedServicePreset, setSelectedServicePreset] = useState<'airport' | 'point_to_point' | 'hourly' | 'day_trip' | null>(null);
  const [bookingResetKey, setBookingResetKey] = useState(0);

  const scrollToBooking = (resetToStep1 = true) => {
    setActiveTab('book');
    if (resetToStep1) {
      setBookingResetKey(prev => prev + 1);
    }
    const el = document.getElementById('booking-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      setTimeout(() => {
        const input = document.getElementById('booking-pickup-input');
        if (input) {
          (input as HTMLInputElement).focus();
        }
      }, 400);
    }
  };

  const scrollToFleet = () => {
    setActiveTab('fleet');
    const el = document.getElementById('fleet');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectServiceFromBento = (service: 'airport' | 'point_to_point' | 'hourly' | 'day_trip') => {
    setSelectedServicePreset(service);
    setActiveTab('book');
    scrollToBooking(true);
  };

  const handleSelectVehicle = (vehicleId: string) => {
    setSelectedVehiclePreset(vehicleId);
    setActiveTab('book');
    scrollToBooking(false);
  };

  const handleSelectDayTrip = (tripId: string) => {
    setSelectedDayTripPreset(tripId);
    setSelectedServicePreset('day_trip');
    setActiveTab('book');
    scrollToBooking(false);
  };

  const handleBookRouteFromRates = (pickup: string, dropoff: string) => {
    setSelectedPickupPreset(pickup);
    setSelectedDropoffPreset(dropoff);
    setSelectedServicePreset('point_to_point');
    setActiveTab('book');
    scrollToBooking(false);
  };

  const handleBookingConfirmed = (booking: ActiveBookingRecord) => {
    setActiveBooking(booking);
  };

  const handleOpenTrackerForBooking = (booking: ActiveBookingRecord) => {
    setActiveBooking(booking);
    setIsTrackerOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#070d18] text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950 pb-16 lg:pb-0">
      
      {/* 3-Zone Header Navigation */}
      <Header
        onOpenBooking={() => {
          setPanelMode('rider');
          setActiveTab('book');
          scrollToBooking();
        }}
        onOpenTracker={() => setIsTrackerOpen(true)}
        currency={currency}
        setCurrency={setCurrency}
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setPanelMode('rider');
          setActiveTab(tab);
          if (tab === 'book') scrollToBooking(false);
        }}
        panelMode={panelMode}
        onSelectPanelMode={(mode) => setPanelMode(mode)}
      />

      {/* Sleek Segmented Bar / Friendly Options Navigation */}
      <div className="sticky top-16 z-30 bg-[#070d18]/95 backdrop-blur-md border-b border-slate-800/80 py-2 px-3 sm:px-6 shadow-xl">
        <div className="max-w-5xl mx-auto flex items-center justify-between gap-3">
          {panelMode === 'rider' ? (
            <>
              <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 rounded-xl border border-slate-800 text-xs overflow-x-auto no-scrollbar w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('book');
                    scrollToBooking(false);
                  }}
                  className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${
                    activeTab === 'book'
                      ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold shadow-md'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <span>🚕 Book Chauffeur</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('fleet')}
                  className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${
                    activeTab === 'fleet'
                      ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold shadow-md'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <span>🚘 Fleet &amp; Rates</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('trips')}
                  className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${
                    activeTab === 'trips'
                      ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold shadow-md'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <span>⛰️ Day Trips</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('about')}
                  className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${
                    activeTab === 'about'
                      ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold shadow-md'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <span>🛡️ About &amp; VTC</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('contact')}
                  className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${
                    activeTab === 'contact'
                      ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold shadow-md'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <span>💬 24/7 Concierge</span>
                </button>
              </div>

              {/* Quick Ride Tracker, Download ZIP, and Driver Switcher shortcuts */}
              <div className="hidden sm:flex items-center gap-2 text-xs shrink-0">
                <a
                  href="/mr-driver-barcelona.zip"
                  download="mr-driver-barcelona.zip"
                  className="px-3 py-1.5 rounded-lg border border-amber-500/60 bg-gradient-to-r from-amber-500/20 to-amber-400/10 hover:bg-amber-500/30 text-amber-300 font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-sm"
                  title="Download complete source code and assets as ZIP"
                >
                  <span>📦 Download ZIP</span>
                </a>
                <button
                  type="button"
                  onClick={() => setIsTrackerOpen(true)}
                  className="px-3 py-1.5 rounded-lg border border-slate-700/80 bg-slate-900/90 hover:border-amber-400 text-slate-300 hover:text-white transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <span>🔍 Ride Status</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPanelMode('driver')}
                  className="px-3 py-1.5 rounded-lg border border-amber-500/50 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 font-semibold transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <span>🚘 Driver Cockpit</span>
                </button>
              </div>
            </>
          ) : (
            <div className="w-full flex items-center justify-between gap-4">
              <div className="flex items-center gap-2.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="text-xs sm:text-sm font-bold text-white">
                  Chauffeur Cockpit <span className="text-amber-400 font-mono text-xs">(Alejandro M. • Plate: 9421-LMB)</span>
                </span>
              </div>
              <button
                type="button"
                onClick={() => setPanelMode('rider')}
                className="px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5"
              >
                <span>← Back to Rider View</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Experience: Clean Single-Screen Portal */}
      <main className="flex-1">
        {panelMode === 'driver' ? (
          <DriverPanel
            currency={currency}
            onSwitchToRider={() => setPanelMode('rider')}
          />
        ) : (
          <div className="py-2">
            {activeTab === 'book' && (
              <div className="space-y-4">
                {/* Visual friendly options cards at the top */}
                <CompactHub
                  onSelectService={handleSelectServiceFromBento}
                  onOpenFleet={() => setActiveTab('fleet')}
                  onOpenDayTrips={() => setActiveTab('trips')}
                  onOpenContact={() => setActiveTab('contact')}
                />

                {/* Step-by-Step Interactive Booking Engine */}
                <section id="booking-section" className="pb-12 scroll-mt-24">
                  <div id="booking" className="absolute -top-24 pointer-events-none" />
                  <BookingEngine
                    currency={currency}
                    onBookingConfirmed={handleBookingConfirmed}
                    onOpenTracker={() => setIsTrackerOpen(true)}
                    selectedVehiclePreset={selectedVehiclePreset}
                    selectedDayTripPreset={selectedDayTripPreset}
                    selectedPickupPreset={selectedPickupPreset}
                    selectedDropoffPreset={selectedDropoffPreset}
                    selectedServicePreset={selectedServicePreset}
                    bookingResetKey={bookingResetKey}
                  />
                </section>
              </div>
            )}

            {activeTab === 'fleet' && (
              <div className="space-y-6">
                <FleetSection
                  currency={currency}
                  onSelectVehicle={handleSelectVehicle}
                />
                <RatesTable
                  currency={currency}
                  onBookRoute={handleBookRouteFromRates}
                />
              </div>
            )}

            {activeTab === 'trips' && (
              <DayTripsSection
                currency={currency}
                onSelectDayTrip={handleSelectDayTrip}
              />
            )}

            {activeTab === 'about' && (
              <div className="space-y-6">
                <VipBenefits />
                <AboutSection />
              </div>
            )}

            {activeTab === 'contact' && (
              <ContactSection />
            )}
          </div>
        )}
      </main>

      {/* Mobile Sticky Bottom Navigation Bar (App Experience) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#091122]/95 backdrop-blur-md border-t border-slate-800 px-3 py-2 flex items-center justify-around shadow-2xl">
        {panelMode === 'rider' ? (
          <>
            <button
              type="button"
              onClick={() => {
                setActiveTab('book');
                scrollToBooking(false);
              }}
              className={`flex flex-col items-center gap-0.5 text-[10px] cursor-pointer transition-colors ${
                activeTab === 'book' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              <span className="text-sm">🚕</span>
              <span>Book</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('fleet')}
              className={`flex flex-col items-center gap-0.5 text-[10px] cursor-pointer transition-colors ${
                activeTab === 'fleet' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              <span className="text-sm">🚘</span>
              <span>Fleet</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('trips')}
              className={`flex flex-col items-center gap-0.5 text-[10px] cursor-pointer transition-colors ${
                activeTab === 'trips' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              <span className="text-sm">⛰️</span>
              <span>Tours</span>
            </button>

            <button
              type="button"
              onClick={() => setPanelMode('driver')}
              className="flex flex-col items-center gap-0.5 text-[10px] text-amber-400 hover:text-amber-300 font-bold cursor-pointer"
            >
              <span className="text-sm">👨‍✈️</span>
              <span>Driver</span>
            </button>

            <a
              href="https://wa.me/34662524244"
              target="_blank"
              rel="noreferrer"
              className="flex flex-col items-center gap-0.5 text-[10px] text-emerald-400 font-bold cursor-pointer"
            >
              <span className="text-sm">🟢</span>
              <span>WhatsApp</span>
            </a>
          </>
        ) : (
          <>
            <button
              type="button"
              onClick={() => setPanelMode('driver')}
              className="flex flex-col items-center gap-0.5 text-[10px] text-amber-400 font-bold cursor-pointer"
            >
              <span className="text-sm">📋</span>
              <span>Dispatch</span>
            </button>

            <a
              href="tel:+34662524244"
              className="flex flex-col items-center gap-0.5 text-[10px] text-slate-300 hover:text-white cursor-pointer"
            >
              <span className="text-sm">📞</span>
              <span>Base Call</span>
            </a>

            <a
              href="https://wa.me/34662524244"
              target="_blank"
              rel="noreferrer"
              className="flex flex-col items-center gap-0.5 text-[10px] text-emerald-400 font-bold cursor-pointer"
            >
              <span className="text-sm">🟢</span>
              <span>WhatsApp</span>
            </a>

            <button
              type="button"
              onClick={() => setPanelMode('rider')}
              className="flex flex-col items-center gap-0.5 text-[10px] text-amber-300 font-semibold cursor-pointer"
            >
              <span className="text-sm">👤</span>
              <span>Rider Mode</span>
            </button>
          </>
        )}
      </nav>

      {/* Footer */}
      <Footer />

      {/* Live Chauffeur Tracker Radar Modal */}
      <RideTrackerModal
        isOpen={isTrackerOpen}
        onClose={() => setIsTrackerOpen(false)}
        activeBooking={activeBooking}
      />

      {/* Floating 24/7 WhatsApp Concierge */}
      <WhatsAppFloating />

      {/* Progressive Web App (PWA) Mobile Install Banner */}
      <PWAInstallButton variant="banner" />

      {/* Network Connectivity Offline Warning Toast */}
      <OfflineIndicator />

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
